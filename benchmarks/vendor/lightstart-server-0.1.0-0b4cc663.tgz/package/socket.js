/**
 * @file Websockets as a route sees them. A route answers `upgrade(c, channel)`, and an adapter whose
 * platform takes websockets accepts the connection and hands `channel` the `Socket`: `open` once,
 * `message` for each text message, `binary` for each binary one, `close` once when either side
 * closes or the connection drops. The upgrade is a request like any other until then, so it runs
 * the app's hooks and middleware, a route may refuse it with any reply, and `pass()` lets a host try
 * what sits behind the app. A plain request to a websocket route is answered 426, and an adapter
 * that takes no websockets answers 501.
 */
import { Reply, fail } from "./reply.js";
                                            

/** One accepted websocket, as its channel holds it. After a close, sends are dropped. */
export          class Socket {
  closed = false;

  /** Sends a text message for a string, a binary one for bytes. */
                                                 

  /** Closes with `code` and `reason` (1000, "" by default); the channel's `close` follows once. */
                                                       
}

/** What a websocket route does with its socket; each method does nothing until a subclass says otherwise. */
export class Channel {
  open(_socket        )       {}

  message(_socket        , _text        )       {}

  binary(_socket        , _data            )       {}

  /** Once, when the socket closed: the code the closing side sent (1005 when it sent none, 1006 when the connection dropped). */
  close(_socket        , _code        , _reason        )       {}
}

/** Whether `c` asks to become a websocket. */
export const upgrading = (c         )          => {
  const asked = c.header("upgrade");
  return asked !== null && asked.toLowerCase() === "websocket";
};

/** Accepts the websocket `c` asks for, on `channel`; a request that asks none is answered 426. */
export const upgrade = (c         , channel         )        => {
  if (!upgrading(c)) return fail("this route takes websockets: ask with upgrade: websocket", 426).header("upgrade", "websocket");
  const reply = new Reply(101);
  reply.channel = channel;
  return reply;
};

/** What an adapter that takes no websockets answers in place of an `upgrade` reply. */
export const unaccepted = ()        => fail("this server takes no websockets", 501);
