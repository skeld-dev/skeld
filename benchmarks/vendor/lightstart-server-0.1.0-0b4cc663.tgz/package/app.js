/**
 * @file The server as declared: routes, the middleware every route runs, the hooks around every
 * request, plugins, and other apps mounted under a prefix. Nothing is composed per request: the
 * first request (or an explicit `build()`) sets the plugins up, files every route in the router and
 * fixes each route's chain, the app's middleware outermost and the route's own inside it, so a
 * route with none calls its handler directly.
 *
 * A request runs the `onRequest` hooks first (any may answer, which ends it: a CORS preflight, a
 * health check, a refusal), then its route's chain, then the `onReply` hooks over whatever
 * answered (headers a plugin adds to every reply, a log line). A GET or HEAD that answers 2xx
 * with a matching validator becomes a 304 after the hooks (`conditional.ts`). A thrown value
 * passes the `mapError` mappers in order, then the `onError` handler, then the default: an
 * `HttpError` answers its status and anything else is logged and answers 500. `handle` answers
 * null for a path no route matches, or one whose route answered `pass()`, so a host can try what
 * sits behind the app; `dispatch` answers the not-found handler's reply instead, which is what an
 * adapter calls.
 */
import { conditional } from "./conditional.js";
import { Context } from "./context.js";
import { HttpError } from "./errors.js";
import { Logger } from "./logger.js";
import { Plugin, ordered } from "./plugin.js";
import { Reply, fail } from "./reply.js";
import { ALL,                                Route, Router } from "./router.js";

/** Runs before routing; a reply ends the request with it, null lets it go on. */
                                                       

/** Runs over every reply the app gives, before the adapter writes it. */
                                                           

/** Turns what a handler threw into the reply. */
                                                                 

/** Answers a thrown value with a reply, or null to let the next mapper (then `onError`, then the default) try. */
                                                                       

class Declaration {
           method        ;
           pattern        ;
           handlerFn         ;
           own              ;

  constructor(method        , pattern        , handlerFn         , own              ) {
    this.method = method;
    this.pattern = pattern;
    this.handlerFn = handlerFn;
    this.own = own;
  }
}

class Mount {
           prefix        ;
           app     ;

  constructor(prefix        , app     ) {
    this.prefix = prefix;
    this.app = app;
  }
}

const joined = (prefix        , pattern        )         => (prefix === "" ? pattern : pattern === "/" ? prefix : prefix + pattern);

const last = async (c         , route       )                 => await route.handlerFn(c);

const run = (c         , route       , i        )                 => {
  if (i === route.chain.length) return last(c, route);
  const middleware = route.chain[i] ;
  return middleware(c, () => run(c, route, i + 1));
};

const defaultNotFound          = (c         )        => fail("no route for " + c.method + " " + c.path, 404);

const settleSecure = (reply       , indices          , protocol        )       => {
  reply.autoSecure = null;
  if (protocol !== "https") return;
  const values = reply.headers.values;
  const names = reply.headers.names;
  for (const index of indices) {
    if (index < names.length && names[index] === "set-cookie") values[index] = values[index]  + "; Secure";
  }
};

export class App {
                   router = new Router();
                   declarations                = [];
                   middleware               = [];
                   requestHooks                = [];
                   replyHooks              = [];
                   plugins           = [];
                   mounts          = [];
                   mappers                = [];
          errorFn                      = null;
  /** Where the app's own complaints go; `logTo` replaces it. */
  logger         = new Logger();
          notFoundFn          = defaultNotFound;
          prepared = false;
          built = false;

  /** Declares the route for `method` and `pattern`, with middleware of its own run inside the app's. */
  on(method        , pattern        , handlerFn         , middleware               = [])      {
    this.unbuilt("a route");
    this.declarations.push(new Declaration(method.toUpperCase(), pattern, handlerFn, middleware));
    return this;
  }

  get(pattern        , handlerFn         , middleware               = [])      {
    return this.on("GET", pattern, handlerFn, middleware);
  }

  post(pattern        , handlerFn         , middleware               = [])      {
    return this.on("POST", pattern, handlerFn, middleware);
  }

  put(pattern        , handlerFn         , middleware               = [])      {
    return this.on("PUT", pattern, handlerFn, middleware);
  }

  patch(pattern        , handlerFn         , middleware               = [])      {
    return this.on("PATCH", pattern, handlerFn, middleware);
  }

  delete(pattern        , handlerFn         , middleware               = [])      {
    return this.on("DELETE", pattern, handlerFn, middleware);
  }

  options(pattern        , handlerFn         , middleware               = [])      {
    return this.on("OPTIONS", pattern, handlerFn, middleware);
  }

  /** The route for every method the pattern has no route of its own for. */
  all(pattern        , handlerFn         , middleware               = [])      {
    return this.on(ALL, pattern, handlerFn, middleware);
  }

  /** Middleware every route runs, outside the route's own, in the order added. */
  use(middleware            )      {
    this.unbuilt("middleware");
    this.middleware.push(middleware);
    return this;
  }

  onRequest(hook             )      {
    this.unbuilt("a hook");
    this.requestHooks.push(hook);
    return this;
  }

  onReply(hook           )      {
    this.unbuilt("a hook");
    this.replyHooks.push(hook);
    return this;
  }

  /** Replaces the default error handler, under which an `HttpError` answers its status and message and anything else is logged and answers 500. */
  onError(errorFn              )      {
    this.errorFn = errorFn;
    return this;
  }

  /**
   * Adds a mapper tried, in the order added, before `onError` and the default when a handler, a
   * middleware or a hook throws: the first reply it answers wins and null lets the next one try. A
   * mapper that throws is logged and answers the default 500, as anything else unexpected does.
   */
  mapError(mapper             )      {
    this.mappers.push(mapper);
    return this;
  }

  logTo(logger        )      {
    this.logger = logger;
    return this;
  }

  /** What `dispatch` answers for a path no route matches. */
  notFound(notFoundFn         )      {
    this.notFoundFn = notFoundFn;
    return this;
  }

  plugin(plugin        )      {
    this.unbuilt("a plugin");
    this.plugins.push(plugin);
    return this;
  }

  /**
   * Serves `app`'s routes under `prefix` ("/api"), each running `app`'s middleware inside this app's.
   * The mounted app's hooks would run for its routes alone, which the request pipeline has no place
   * for, so a mounted app with hooks is refused.
   */
  mount(prefix        , app     )      {
    this.unbuilt("a mount");
    if (!prefix.startsWith("/") || prefix.endsWith("/")) throw new Error("a mount prefix starts with / and does not end with one: \"" + prefix + "\"");
    this.mounts.push(new Mount(prefix, app));
    return this;
  }

          unbuilt(what        )       {
    if (this.built) throw new Error("the app is built: " + what + " cannot be added after its first request");
  }

  /** Sets the plugins up, once: a mounting app does it for the apps it mounts. */
          prepare()       {
    if (this.prepared) return;
    this.prepared = true;
    for (const plugin of ordered(this.plugins)) plugin.setup(this);
    for (const m of this.mounts) m.app.prepare();
  }

  /** The routes with their chains, under `prefix`, outermost middleware first. */
          routes(prefix        , outer              )          {
    const around = outer.concat(this.middleware);
    const out          = [];
    for (const d of this.declarations) out.push(new Route(d.method, joined(prefix, d.pattern), d.handlerFn, around.concat(d.own)));
    for (const m of this.mounts) {
      if (m.app.requestHooks.length > 0 || m.app.replyHooks.length > 0) throw new Error("the app mounted at " + m.prefix + " has hooks, which a mounted app cannot run; add them to the app that mounts it");
      for (const r of m.app.routes(joined(prefix, m.prefix), around)) out.push(r);
    }
    return out;
  }

  /** Sets the plugins up and files the routes; the first request does it when nothing did before. */
  build()      {
    if (this.built) return this;
    this.prepare();
    for (const route of this.routes("", [])) this.router.add(route);
    this.built = true;
    return this;
  }

          fault(c         , error         )        {
    try {
      for (const mapper of this.mappers) {
        const reply = mapper(c, error);
        if (reply !== null) return reply;
      }
    } catch (failure) {
      this.logger.error(c.method + " " + c.path, failure);
      return fail("internal error", 500);
    }
    if (this.errorFn !== null) return this.errorFn(c, error);
    if (error instanceof HttpError) return fail(error.message, error.status);
    this.logger.error(c.method + " " + c.path, error);
    return fail("internal error", 500);
  }

          finish(c         , reply       )        {
    const before = reply.autoSecure;
    if (before !== null) settleSecure(reply, before, c.protocol);
    for (const hook of this.replyHooks) hook(c, reply);
    const after = reply.autoSecure;
    if (after !== null) settleSecure(reply, after, c.protocol);
    return conditional(c, reply);
  }

  /** The reply for `c`, or null when no route matches its path (a 405 when one does under another method). */
  async handle(c         )                        {
    if (!this.built) this.build();
    c.logger = this.logger;
    try {
      for (const hook of this.requestHooks) {
        const early = hook(c);
        if (early !== null) return early.passed ? null : this.finish(c, early);
      }
      const route = this.router.find(c);
      if (route === null) {
        const allow = this.router.allowed(c.path);
        if (allow.length === 0) return null;
        return this.finish(c, fail("method " + c.method + " not allowed", 405).header("allow", allow.join(", ")));
      }
      const reply = await (route.chain.length === 0 ? route.handlerFn(c) : run(c, route, 0));
      if (reply.passed) return null;
      return this.finish(c, reply);
    } catch (error) {
      return this.finish(c, this.fault(c, error));
    }
  }

  /** The reply for `c`, the not-found handler's when no route matches. */
  async dispatch(c         )                 {
    const reply = await this.handle(c);
    if (reply !== null) return reply;
    try {
      return this.finish(c, await this.notFoundFn(c));
    } catch (error) {
      return this.finish(c, this.fault(c, error));
    }
  }
}
