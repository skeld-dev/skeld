import { Context } from "./context.js";
import { Logger } from "./logger.js";
import { Plugin } from "./plugin.js";
import { Reply } from "./reply.js";
import { type Handler, type Middleware } from "./router.js";
/** Runs before routing; a reply ends the request with it, null lets it go on. */
export type RequestHook = (c: Context) => Reply | null;
/** Runs over every reply the app gives, before the adapter writes it. */
export type ReplyHook = (c: Context, reply: Reply) => void;
/** Turns what a handler threw into the reply. */
export type ErrorHandler = (c: Context, error: unknown) => Reply;
/** Answers a thrown value with a reply, or null to let the next mapper (then `onError`, then the default) try. */
export type ErrorMapper = (c: Context, error: unknown) => Reply | null;
export declare class App {
    private readonly router;
    private readonly declarations;
    private readonly middleware;
    private readonly requestHooks;
    private readonly replyHooks;
    private readonly plugins;
    private readonly mounts;
    private readonly mappers;
    private errorFn;
    /** Where the app's own complaints go; `logTo` replaces it. */
    logger: Logger;
    private notFoundFn;
    private prepared;
    private built;
    /** Declares the route for `method` and `pattern`, with middleware of its own run inside the app's. */
    on(method: string, pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    get(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    post(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    put(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    patch(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    delete(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    options(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    /** The route for every method the pattern has no route of its own for. */
    all(pattern: string, handlerFn: Handler, middleware?: Middleware[]): App;
    /** Middleware every route runs, outside the route's own, in the order added. */
    use(middleware: Middleware): App;
    onRequest(hook: RequestHook): App;
    onReply(hook: ReplyHook): App;
    /** Replaces the default error handler, under which an `HttpError` answers its status and message and anything else is logged and answers 500. */
    onError(errorFn: ErrorHandler): App;
    /**
     * Adds a mapper tried, in the order added, before `onError` and the default when a handler, a
     * middleware or a hook throws: the first reply it answers wins and null lets the next one try. A
     * mapper that throws is logged and answers the default 500, as anything else unexpected does.
     */
    mapError(mapper: ErrorMapper): App;
    logTo(logger: Logger): App;
    /** What `dispatch` answers for a path no route matches. */
    notFound(notFoundFn: Handler): App;
    plugin(plugin: Plugin): App;
    /**
     * Serves `app`'s routes under `prefix` ("/api"), each running `app`'s middleware inside this app's.
     * The mounted app's hooks would run for its routes alone, which the request pipeline has no place
     * for, so a mounted app with hooks is refused.
     */
    mount(prefix: string, app: App): App;
    private unbuilt;
    /** Sets the plugins up, once: a mounting app does it for the apps it mounts. */
    private prepare;
    /** The routes with their chains, under `prefix`, outermost middleware first. */
    private routes;
    /** Sets the plugins up and files the routes; the first request does it when nothing did before. */
    build(): App;
    private fault;
    private finish;
    /** The reply for `c`, or null when no route matches its path (a 405 when one does under another method). */
    handle(c: Context): Promise<Reply | null>;
    /** The reply for `c`, the not-found handler's when no route matches. */
    dispatch(c: Context): Promise<Reply>;
}
