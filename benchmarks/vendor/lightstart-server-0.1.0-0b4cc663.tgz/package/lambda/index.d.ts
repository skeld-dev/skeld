/**
 * @file The AWS Lambda adapter, for API Gateway HTTP APIs and Lambda function URLs (the version 2.0
 * event): `export const handler = toLambda(app)`. The event's method, raw path and query, headers,
 * cookies, source address and body (base64 when the event says so) become the `Incoming`; the
 * reply becomes the result object, a whole body as text or, when it is bytes, base64, a streamed
 * body collected first, every `set-cookie` in `cookies`. Lambda freezes the process once the
 * handler returns, so the work handed to `waitUntil` is awaited before the result goes back. It
 * reaches nothing of the core but its public entry, which is all an adapter of another package
 * needs; it runs on Lambda's node runtime and uses node's `Buffer` for base64. An `upgrade`
 * reply is answered 501: API Gateway's websocket APIs send another kind of event.
 */
import { Incoming, Reply, type App } from "../index.js";
/** The version 2.0 event API Gateway and function URLs send. */
export interface LambdaEvent {
    rawPath: string;
    rawQueryString?: string;
    headers?: Record<string, string | undefined>;
    cookies?: string[];
    body?: string;
    isBase64Encoded?: boolean;
    requestContext: {
        domainName?: string;
        http: {
            method: string;
            sourceIp?: string;
        };
    };
}
/** What the handler answers API Gateway or the function URL with. */
export interface LambdaResult {
    statusCode: number;
    headers: Record<string, string>;
    cookies: string[];
    body: string;
    isBase64Encoded: boolean;
}
export declare class LambdaIncoming extends Incoming {
    readonly event: LambdaEvent;
    readonly pending: Promise<void>[];
    private readonly controller;
    private readonly names;
    private readonly values;
    constructor(event: LambdaEvent);
    method(): string;
    target(): string;
    header(name: string): string | null;
    headerPairs(): string[];
    private body;
    text(limit: number): Promise<string>;
    bytes(limit: number): Promise<Uint8Array>;
    remoteAddress(): string;
    host(): string;
    protocol(): string;
    signal(): AbortSignal;
    abort(_reason: string): void;
    waitUntil(work: Promise<void>): void;
}
/** `reply` as Lambda's result object. */
export declare const toResult: (reply: Reply, method: string) => Promise<LambdaResult>;
/** A Lambda handler for `app`, answering once the work handed to `waitUntil` is done. */
export declare const toLambda: (app: App) => (event: LambdaEvent) => Promise<LambdaResult>;
