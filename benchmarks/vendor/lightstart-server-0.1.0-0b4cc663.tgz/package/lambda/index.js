/**
 * @file The AWS Lambda adapter, for API Gateway HTTP APIs and Lambda function URLs (the version 2.0
 * event): `export const handler = toLambda(app)`. The event's method, raw path and query, headers,
 * cookies, source address and body (base64 when the event says so) become the `Incoming`; the
 * reply becomes the result object, a whole body as text or, when it is bytes, base64, a streamed
 * body collected first, every `set-cookie` in `cookies`. Lambda freezes the process once the
 * handler returns, so the work handed to `waitUntil` is awaited before the result goes back. It
 * reaches nothing of the core but its public entry, which is all an adapter of another package
 * needs; it runs on Lambda's node runtime and uses node's `Buffer` for base64. An `upgrade`
 * reply is answered 501: API Gateway's websocket APIs send another kind of event.
 */
import { Context, HttpError, Incoming, Reply, Writer, unaccepted,          } from "../index.js";

/** The version 2.0 event API Gateway and function URLs send. */
                              
                  
                          
                                               
                     
                
                            
                   
                        
                                                
    
 

/** What the handler answers API Gateway or the function URL with. */
                               
                     
                                  
                    
               
                           
 

const tooLarge = (limit        )            => new HttpError(413, "the body is larger than " + String(limit) + " bytes");

export class LambdaIncoming extends Incoming {
           event             ;
           pending                  = [];
                   controller = new AbortController();
                   names           = [];
                   values           = [];

  constructor(event             ) {
    super();
    this.event = event;
    const headers = event.headers ?? {};
    for (const [name, value] of Object.entries(headers)) {
      if (value === undefined) continue;
      this.names.push(name.toLowerCase());
      this.values.push(value);
    }
    const cookies = event.cookies ?? [];
    if (cookies.length > 0 && this.names.indexOf("cookie") < 0) {
      this.names.push("cookie");
      this.values.push(cookies.join("; "));
    }
  }

  method()         {
    return this.event.requestContext.http.method.toUpperCase();
  }

  target()         {
    const query = this.event.rawQueryString ?? "";
    return query === "" ? this.event.rawPath : this.event.rawPath + "?" + query;
  }

  header(name        )                {
    let out                = null;
    for (let i = 0; i < this.names.length; i++) if (this.names[i] === name) out = out === null ? this.values[i]  : out + ", " + this.values[i] ;
    return out;
  }

  headerPairs()           {
    const out           = [];
    for (let i = 0; i < this.names.length; i++) {
      out.push(this.names[i] );
      out.push(this.values[i] );
    }
    return out;
  }

          body()         {
    const body = this.event.body ?? "";
    return Buffer.from(body, this.event.isBase64Encoded === true ? "base64" : "utf8");
  }

  text(limit        )                  {
    const body = this.body();
    if (body.length > limit) return Promise.reject(tooLarge(limit));
    return Promise.resolve(body.toString("utf8"));
  }

  bytes(limit        )                      {
    const body = this.body();
    if (body.length > limit) return Promise.reject(tooLarge(limit));
    return Promise.resolve(body);
  }

  remoteAddress()         {
    return this.event.requestContext.http.sourceIp ?? "";
  }

           host()         {
    return this.header("host") ?? this.event.requestContext.domainName ?? "";
  }

  protocol()         {
    return "https";
  }

  signal()              {
    return this.controller.signal;
  }

           abort(_reason        )       {
    this.controller.abort();
  }

  waitUntil(work               )       {
    this.pending.push(work);
  }
}

class Collector extends Writer {
           chunks           = [];

  write(chunk                     )                {
    this.chunks.push(typeof chunk === "string" ? Buffer.from(chunk, "utf8") : Buffer.from(chunk));
    return Promise.resolve();
  }
}

const textual = (type               )          =>
  type === null || type.startsWith("text/") || type.indexOf("json") >= 0 || type.indexOf("xml") >= 0 || type.indexOf("javascript") >= 0 || type.startsWith("application/x-www-form-urlencoded");

const bodyOf = async (reply       )                           => {
  if (reply.text !== null) return reply.text;
  if (reply.bytes !== null) return Buffer.from(reply.bytes);
  if (reply.stream !== null) {
    const out = new Collector();
    await reply.stream(out);
    return Buffer.concat(out.chunks);
  }
  if (reply.response !== null) return Buffer.from(await reply.response.arrayBuffer());
  return "";
};

/** `reply` as Lambda's result object. */
export const toResult = async (reply       , method        )                        => {
  if (reply.channel !== null) return toResult(unaccepted(), method);
  const headers                         = {};
  const cookies           = [];
  const names           = [];
  const values           = [];
  if (reply.response !== null)
    reply.response.headers.forEach((value        , name        ) => {
      names.push(name);
      values.push(value);
    });
  for (let i = 0; i < reply.headers.names.length; i++) {
    names.push(reply.headers.names[i] );
    values.push(reply.headers.values[i] );
  }
  for (let i = 0; i < names.length; i++) {
    const name = names[i] ;
    if (name === "set-cookie") cookies.push(values[i] );
    else headers[name] = headers[name] === undefined ? values[i]  : headers[name] + ", " + values[i] ;
  }
  const status = reply.response !== null ? reply.response.status : reply.status;
  const body = method === "HEAD" ? "" : await bodyOf(reply);
  if (typeof body === "string") return { statusCode: status, headers, cookies, body, isBase64Encoded: false };
  if (textual(headers["content-type"] ?? null)) return { statusCode: status, headers, cookies, body: body.toString("utf8"), isBase64Encoded: false };
  return { statusCode: status, headers, cookies, body: body.toString("base64"), isBase64Encoded: true };
};

/** A Lambda handler for `app`, answering once the work handed to `waitUntil` is done. */
export const toLambda = (app     ) => {
  app.build();
  return async (event             )                        => {
    const incoming = new LambdaIncoming(event);
    const c = new Context(incoming);
    const reply = await app.dispatch(c);
    const result = await toResult(reply, c.method);
    await Promise.all(incoming.pending);
    return result;
  };
};
