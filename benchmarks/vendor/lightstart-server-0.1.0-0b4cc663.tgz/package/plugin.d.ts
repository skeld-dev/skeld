/**
 * @file A plugin: one feature of a server as a unit that can be left out (CORS, static files, a
 * proxy's trust, a set of endpoints). It is made with its options and contributes in `setup`,
 * through the app it is handed: routes, middleware, hooks, a mounted app. The app sets its plugins
 * up when it is built, each after the plugins its `requires` names, in the order they were added
 * otherwise; a requirement no plugin meets, or a loop, refuses the build.
 */
import type { App } from "./app.js";
export declare abstract class Plugin {
    /** The name other plugins require it by ("cors"). */
    readonly id: string;
    /** The plugins that must be set up before this one. */
    readonly requires: string[];
    constructor(id: string, requires: string[]);
    abstract setup(app: App): void;
}
/**
 * `plugins` in the order their requirements allow, else the order given; throws on a missing
 * requirement or a loop. The same plugin may be added more than once (two static folders); a
 * requirement is met once every plugin of that id is set up.
 */
export declare const ordered: (plugins: Plugin[]) => Plugin[];
