/**
 * @file RFC 9110 conditional replies, applied by the app where it finishes a reply: a GET or HEAD
 * with a 2xx answer carrying an `etag` becomes a bodiless 304 when the request's `If-None-Match`
 * matches it under weak comparison (a comma list, `*` included); with no `If-None-Match`, a
 * `last-modified` not later than the request's `If-Modified-Since` does the same. A 304 keeps the
 * validators and cache headers (`etag`, `cache-control`, `content-location`, `date`, `expires`,
 * `vary`, `set-cookie`) and drops the body, so a stream it would have sent is never started. The
 * method and status are checked before any header is read, and a reply with neither validator
 * costs only two header lookups.
 */
import type { Context } from "./context.js";
import type { Reply } from "./reply.js";
/**
 * Whether the request's `If-None-Match` already names `etag` (a GET or HEAD only), so a route can
 * answer 304 before doing the work its reply would cost: `if (fresh(c, tag)) return empty(304).header("etag", tag)`.
 */
export declare const fresh: (c: Context, etag: string) => boolean;
/** Turns `reply` into a 304 when the request's validators say the client's copy is current, else answers it as it is. */
export declare const conditional: (c: Context, reply: Reply) => Reply;
