/**
 * @file What a handler answers: a status, a `HeaderList`, and at most one body, each kind in a field
 * of its own so an adapter reads the one that is set without narrowing a union. `text` and `bytes`
 * are whole bodies an adapter frames with a `content-length`; `stream` is written chunk by chunk
 * through a `Writer` (node's `res.write`, a `ReadableStream` on fetch runtimes); `response` is a
 * Fetch `Response` a fetch adapter passes on untouched and the node adapter copies out; `channel`
 * is the websocket an `upgrade` accepts (`socket.ts`). The
 * builders below are how a handler makes one: `return json({ ok: true })`.
 */
import { HeaderList } from "./headers.js";
import type { Channel } from "./socket.js";
/**
 * Where a streamed body goes. `write` resolves once the chunk may be followed by the next (node's
 * backpressure); after the client has gone `closed` is true and writes are dropped.
 */
export declare abstract class Writer {
    closed: boolean;
    abstract write(chunk: string | Uint8Array): Promise<void>;
}
/** A streamed body: called once with the writer, the body ends when its promise settles. */
export type StreamBody = (out: Writer) => Promise<void>;
export declare class Reply {
    status: number;
    readonly headers: HeaderList;
    text: string | null;
    bytes: Uint8Array | null;
    stream: StreamBody | null;
    response: Response | null;
    /** The websocket the request becomes, where the adapter takes one (`upgrade(c, channel)`). */
    channel: Channel | null;
    /** The route declined the request after its pattern matched: the app answers null, as for a path nothing matches (`pass()`). */
    passed: boolean;
    /** Indices in `headers` of the `set-cookie` values whose `Secure` is settled when the app finishes the reply (`cookies.ts`). */
    autoSecure: number[] | null;
    constructor(status: number);
    /** Sets a header and answers the reply, so a builder's result can be extended in one expression. */
    header(name: string, value: string): Reply;
}
/** A JSON body: `data` stringified, with `application/json`. `data` is a record or an array, never a class instance. */
export declare const json: (data: unknown, status?: number) => Reply;
/** `{ "error": message }` with `status` and `cache-control: no-store`: a refusal. */
export declare const fail: (message: string, status: number) => Reply;
/** A plain text body. */
export declare const text: (body: string, status?: number) => Reply;
/** An HTML body. */
export declare const html: (body: string, status?: number) => Reply;
/** A body of bytes with the content type given. */
export declare const bytes: (body: Uint8Array, type: string, status?: number) => Reply;
/** No body: a 204 by default, or a 304, a 201 with a `location`, a HEAD's answer. */
export declare const empty: (status?: number) => Reply;
/** A redirect to `location`, 302 unless told otherwise. */
export declare const redirect: (location: string, status?: number) => Reply;
/** A streamed body of `type`: the adapter sends the headers, then whatever `body` writes, then ends. */
export declare const stream: (body: StreamBody, type: string, status?: number) => Reply;
/** Server-sent events over a streamed body: `send` writes one event, `comment` a line the client ignores (a keep-alive). */
export declare class EventSink {
    readonly out: Writer;
    constructor(out: Writer);
    /** Whether the client has gone, after which nothing more is sent. */
    get closed(): boolean;
    /** One event: its data (each line its own `data:`), and an event name and an id when given. */
    send(data: string, event?: string, id?: string): Promise<void>;
    comment(text: string): Promise<void>;
}
/**
 * An event stream: `sse(async (events) => { await events.send("hi") })`. Never cached, and marked
 * unbuffered for a proxy in front (nginx's `x-accel-buffering`), so each event reaches the client
 * when it is sent.
 */
export declare const sse: (body: (events: EventSink) => Promise<void>) => Reply;
/**
 * A route declining a request its pattern matched, because what it serves is
 * decided per request (a model that may not exist, a file that may not be
 * there): `app.handle` answers null, so a host tries what sits behind the app,
 * and `app.dispatch` answers the not-found reply.
 */
export declare const pass: () => Reply;
/** A Fetch `Response` as a reply: passed on as it is where the adapter speaks Fetch, copied out where it does not. */
export declare const respond: (response: Response) => Reply;
