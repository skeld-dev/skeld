/**
 * @file A reply's headers as two parallel lists, names lower-cased and values as given, in the
 * order they were added. A repeated name keeps every value, so two `set-cookie` headers are two
 * entries and reach the wire as two lines; `get` joins a repeated name with ", ", as Fetch's
 * `Headers` does for every name but `set-cookie`. The node adapter writes `flat()` in one
 * `writeHead` call and the fetch adapter builds a `Headers` from the same pairs.
 */
export declare class HeaderList {
    readonly names: string[];
    readonly values: string[];
    /** Replaces every value of `name` with `value`. */
    set(name: string, value: string): void;
    private setLower;
    /** Adds `value` after the values `name` already has. */
    append(name: string, value: string): void;
    /** `append` for a name that is already lower-cased, as every one the package writes is. */
    appendLower(name: string, value: string): void;
    /** Sets `name` only when it has no value yet. */
    default(name: string, value: string): void;
    /** `default` for a name that is already lower-cased. */
    defaultLower(name: string, value: string): void;
    /** The values of `name` joined with ", ", or null when it has none. */
    get(name: string): string | null;
    /** Every value of `name`, in order: the form a repeated `set-cookie` is read in. */
    all(name: string): string[];
    has(name: string): boolean;
    /** Removes every value of `name`. */
    delete(name: string): void;
    private deleteLower;
    get size(): number;
    /** Name, value, name, value: the array form node's `writeHead` takes. */
    flat(): string[];
}
