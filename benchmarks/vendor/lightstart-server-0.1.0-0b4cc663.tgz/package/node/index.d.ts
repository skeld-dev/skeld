/**
 * @file The node adapter, for node and for a binary scriptc compiled (whose `node:http` is its own
 * native server): `serve(app, options)` listens and answers every request with `app.dispatch`.
 * Work handed to `waitUntil` runs after the reply and is counted, so `close()` stops accepting,
 * lets the open connections finish (dropping them once `grace` runs out) and waits for that work;
 * with `signals`, a SIGTERM or SIGINT closes the server that way and exits. A handler that throws
 * past the app's error handler, or a reply that cannot be written, ends that response with a bare
 * 500 or drops the connection once the headers are out. With `sockets`, an upgrade request goes to
 * the app too, and a route's `upgrade(c, channel)` becomes a websocket (`socket.ts`); `close()`
 * closes the open ones 1001 first.
 */
import { type Server } from "node:http";
import { WorkTracker } from "./incoming.js";
import { Sockets, type SocketOptions } from "./socket.js";
import type { App } from "../app.js";
export { MessageIncoming, NodeIncoming, WorkTracker } from "./incoming.js";
export { NodeSocket, Sockets, UpgradeIncoming, acceptUpgrades, type SocketOptions } from "./socket.js";
export { NodeCrypto } from "./crypto.js";
export { NodeWriter, writeReply } from "./write.js";
export { serveThreads, serveWorker, type ServeWorkerOptions, type ThreadsOptions, type ThreadsServer } from "./threads.js";
export interface ServeOptions {
    /** The port, 3000 by default; 0 lets the system pick one (read it back as `server.port`). */
    port?: number;
    /** The address to bind, every interface by default. */
    host?: string;
    /** A Unix socket path to listen on instead of a port (Linux and macOS). */
    path?: string;
    /** Let listeners share one explicit port through the kernel's balanced `SO_REUSEPORT` (Linux). */
    reusePort?: boolean;
    /** Close and exit on SIGTERM and SIGINT. */
    signals?: boolean;
    /** Milliseconds `close()` waits for open connections and pending work, 10 seconds by default. */
    grace?: number;
    /** Take websockets: upgrade requests go to the app, with these limits (`{}` for the defaults). */
    sockets?: SocketOptions;
}
export declare class NodeServer extends WorkTracker {
    readonly app: App;
    readonly server: Server;
    /** The port it listens on, 0 on a Unix socket. */
    port: number;
    /** The websockets it accepted, null unless it takes them. */
    sockets: Sockets | null;
    private readonly grace;
    private pending;
    private drained;
    private closing;
    constructor(app: App, grace: number);
    private answer;
    track(work: Promise<void>): void;
    /** Stops accepting, waits for open connections and pending work (at most `grace` ms), and resolves once closed. */
    close(): Promise<void>;
}
/** Listens with `app` and answers once listening. */
export declare const serve: (app: App, options?: ServeOptions) => Promise<NodeServer>;
