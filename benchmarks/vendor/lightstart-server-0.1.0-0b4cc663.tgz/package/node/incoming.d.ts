/**
 * @file A node `IncomingMessage` as the core's `Incoming`. Headers are read off the parsed record
 * by name; the body is read only when a handler asks, refused with a 413 as soon as its declared
 * length or the bytes received pass the limit (the rest is drained, not kept, so the 413 still
 * reaches the client); the abort signal is made at the first ask and fires when the response
 * closes before it finished, at once when that happened before the ask. The `data` listener types its chunk `Buffer` in TypeScript syntax,
 * the form scriptc lowers.
 */
import type { IncomingMessage, ServerResponse } from "node:http";
import { Incoming } from "../incoming.js";
/** Where the work a request hands to `waitUntil` is counted: the server it arrived on. */
export declare abstract class WorkTracker {
    abstract track(work: Promise<void>): void;
}
/**
 * A request read off node's `IncomingMessage`, whichever way it arrived: with a response to write
 * (`NodeIncoming`) or as an upgrade on a bare connection (`UpgradeIncoming` in `socket.ts`). A
 * subclass calls `left()` once the client has gone.
 */
export declare class MessageIncoming extends Incoming {
    readonly req: IncomingMessage;
    private readonly tracker;
    private controller;
    private gone;
    constructor(req: IncomingMessage, tracker: WorkTracker);
    /** The client went away: the signal aborts now, or at once when it is asked for later. */
    protected left(): void;
    method(): string;
    target(): string;
    header(name: string): string | null;
    headerPairs(): string[];
    text(limit: number): Promise<string>;
    bytes(limit: number): Promise<Uint8Array>;
    remoteAddress(): string;
    protocol(): string;
    signal(): AbortSignal;
    abort(_reason: string): void;
    waitUntil(work: Promise<void>): void;
}
/** A request with node's `ServerResponse` to answer it through. */
export declare class NodeIncoming extends MessageIncoming {
    readonly res: ServerResponse;
    constructor(req: IncomingMessage, res: ServerResponse, tracker: WorkTracker);
}
