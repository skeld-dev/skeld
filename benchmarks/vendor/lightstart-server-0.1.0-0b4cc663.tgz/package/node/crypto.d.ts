import { Crypto } from "../crypto.js";
export declare class NodeCrypto extends Crypto {
    hmacSha256(key: string, data: string): string;
    sha256(data: string | Uint8Array): string;
    safeEqual(a: string, b: string): boolean;
    randomToken(bytes: number): string;
}
