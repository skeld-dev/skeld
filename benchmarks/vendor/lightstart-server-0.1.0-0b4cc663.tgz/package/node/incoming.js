/**
 * @file A node `IncomingMessage` as the core's `Incoming`. Headers are read off the parsed record
 * by name; the body is read only when a handler asks, refused with a 413 as soon as its declared
 * length or the bytes received pass the limit (the rest is drained, not kept, so the 413 still
 * reaches the client); the abort signal is made at the first ask and fires when the response
 * closes before it finished, at once when that happened before the ask. The `data` listener types its chunk `Buffer` in TypeScript syntax,
 * the form scriptc lowers.
 */
                                                                 
import { HttpError } from "../errors.js";
import { Incoming } from "../incoming.js";

/** Where the work a request hands to `waitUntil` is counted: the server it arrived on. */
export          class WorkTracker {
                                            
}

const tooLarge = (limit        )            => new HttpError(413, "the body is larger than " + String(limit) + " bytes");

const readBody = (req                 , limit        )                  =>
  new Promise((resolve                        , reject                         ) => {
    const declared = req.headers["content-length"];
    if (declared !== undefined && Number(declared) > limit) {
      req.resume();
      reject(tooLarge(limit));
      return;
    }
    const chunks           = [];
    let size = 0;
    let refused = false;
    req.on("data", (chunk        ) => {
      if (refused) return;
      size += chunk.length;
      if (size > limit) {
        refused = true;
        chunks.length = 0;
        reject(tooLarge(limit));
        return;
      }
      chunks.push(chunk);
    });
    req.on("end", () => {
      if (!refused) resolve(chunks.length === 1 ? chunks[0]  : Buffer.concat(chunks));
    });
    req.on("error", (error       ) => {
      if (!refused) reject(error);
    });
  });

/**
 * A request read off node's `IncomingMessage`, whichever way it arrived: with a response to write
 * (`NodeIncoming`) or as an upgrade on a bare connection (`UpgradeIncoming` in `socket.ts`). A
 * subclass calls `left()` once the client has gone.
 */
export class MessageIncoming extends Incoming {
           req                 ;
                   tracker             ;
          controller                         = null;
          gone = false;

  constructor(req                 , tracker             ) {
    super();
    this.req = req;
    this.tracker = tracker;
  }

  /** The client went away: the signal aborts now, or at once when it is asked for later. */
            left()       {
    this.gone = true;
    if (this.controller !== null) this.controller.abort();
  }

  method()         {
    return this.req.method ?? "GET";
  }

  target()         {
    return this.req.url ?? "/";
  }

  header(name        )                {
    const value = this.req.headers[name];
    if (typeof value === "string") return value;
    if (Array.isArray(value)) return value.join(", ");
    return null;
  }

  headerPairs()           {
    const raw = this.req.rawHeaders;
    const out           = [];
    for (let i = 0; i + 1 < raw.length; i += 2) {
      out.push(raw[i] .toLowerCase());
      out.push(raw[i + 1] );
    }
    return out;
  }

  text(limit        )                  {
    return readBody(this.req, limit).then((body        ) => body.toString("utf8"));
  }

  bytes(limit        )                      {
    return readBody(this.req, limit);
  }

  remoteAddress()         {
    return this.req.socket.remoteAddress ?? "";
  }

  protocol()         {
    return "http";
  }

  signal()              {
    if (this.controller !== null) return this.controller.signal;
    const controller = new AbortController();
    this.controller = controller;
    if (this.gone) controller.abort();
    return controller.signal;
  }

           abort(_reason        )       {
    this.left();
  }

  waitUntil(work               )       {
    this.tracker.track(work);
  }
}

/** A request with node's `ServerResponse` to answer it through. */
export class NodeIncoming extends MessageIncoming {
           res                ;

  constructor(req                 , res                , tracker             ) {
    super(req, tracker);
    this.res = res;
    res.once("close", () => {
      if (!res.writableFinished) this.left();
    });
  }
}
