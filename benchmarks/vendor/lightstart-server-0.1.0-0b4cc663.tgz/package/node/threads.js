/**
 * @file Several cores for the node adapter: `serveThreads` spawns workers the app names, waits for
 * each to listen on one explicit port with kernel-balanced `reusePort`, and closes them together;
 * `serveWorker` is the worker side, serving an app on that port and answering the primary's
 * settings, fallback and close messages. The primary never listens. The app writes the spawn
 * because scriptc needs `new Worker(new URL("./worker.ts", import.meta.url))` in its own module,
 * a URL handed to a library refused with SC2020. Where the kernel has no balanced `reusePort`
 * (`ENOTSUP` or `EOPNOTSUPP`, as on macOS) one worker serves without it, and a warning says so.
 * Messages are plain records: a class instance loses its methods across threads.
 */
import { Worker, parentPort, workerData } from "node:worker_threads";
import { serve,                 } from "./index.js";
                                     
                                                 

/** What `serveThreads` starts: the explicit port, how many workers listen, and how to stop them. */
                                
                        
                           
                         
 

/** The primary's settings: an explicit port, the workers to spawn, and the app's own `spawn`. */
                                 
               
                
                  
                                   
                 
                    
 

/** What a worker serves, read from its options, `workerData`, or the primary's `serve` message. */
                                     
                
                
                          
                 
 

                          
               
                               
                                
                
 

                          
                 
                     
                 
                  
                    
 

                                                
                 
                 
                    
 

const codeOf = (error         )         => {
  if (typeof error === "object" && error !== null) {
    const record = error                      ;
    if (typeof record.code === "string") return record.code;
  }
  return "";
};

const messageOf = (error         )         => (error instanceof Error ? error.message : String(error));

const settingsOf = (record                )                        => {
  const port = typeof record.port === "number" ? record.port : 0;
  if (port <= 0) return null;
  const hostName = typeof record.hostName === "string" ? record.hostName : typeof record.host === "string" ? record.host : undefined;
  const grace = typeof record.grace === "number" ? record.grace : 10000;
  const sockets = typeof record.sockets === "object" && record.sockets !== null ? (record.sockets                 ) : null;
  return { port, hostName, sockets, grace };
};

class Threads                          {
           port        ;
  threads = 0;
                   options                ;
                   grace        ;
                   workers           = [];
                   alive            = [];
          remaining = 0;
          wake                      = null;
          ready = 0;
          want        ;
          fallback = false;
          chosen = -1;
          settled = false;
          closing                       = null;
          resolveListen                      = null;
          rejectListen                                  = null;

  constructor(options                ) {
    this.options = options;
    this.port = options.port;
    this.grace = options.grace ?? 10000;
    this.want = options.threads;
  }

  start()                {
    const listening = new Promise      ((resolve            , reject                        ) => {
      this.resolveListen = resolve;
      this.rejectListen = reject;
    });
    for (let index = 0; index < this.options.threads; index++) this.spawnOne(index);
    return listening;
  }

          spawnOne(index        )       {
    const worker = this.options.spawn(index);
    this.workers.push(worker);
    this.alive.push(true);
    this.remaining++;
    worker.on("message", (message         ) => this.receive(index, message));
    worker.on("error", (error       ) => this.error(index, error));
    worker.on("exit", (_code        ) => this.exited(index));
    const record                = { type: "serve", port: this.options.port, grace: this.grace };
    if (this.options.host !== undefined) record.hostName = this.options.host;
    worker.postMessage(record);
  }

          receive(index        , message         )       {
    if (typeof message !== "object" || message === null) return;
    const record = message                 ;
    const type = typeof record.type === "string" ? record.type : "";
    if (this.fallback && index !== this.chosen) return;
    if (type === "listening") {
      this.ready++;
      if (this.ready >= this.want) this.succeed();
      return;
    }
    if (type === "listen-error") {
      const code = typeof record.code === "string" ? record.code : "";
      const detail = typeof record.message === "string" ? record.message : "listen failed";
      if (!this.fallback && (code === "ENOTSUP" || code === "EOPNOTSUPP")) {
        this.enterFallback(index);
        return;
      }
      this.fail(new Error("worker " + String(index) + " could not listen (" + code + "): " + detail));
    }
  }

          enterFallback(index        )       {
    this.fallback = true;
    this.chosen = index;
    this.want = 1;
    this.ready = 0;
    console.warn("[server] reusePort is not available here: serving on one thread without it");
    for (let i = 0; i < this.workers.length; i++) {
      if (i === index) continue;
      if (this.alive[i] === true) void this.workers[i] .terminate();
    }
    const record                = { type: "fallback", port: this.options.port, grace: this.grace };
    if (this.options.host !== undefined) record.hostName = this.options.host;
    this.workers[index] .postMessage(record);
  }

          succeed()       {
    if (this.settled) return;
    this.settled = true;
    this.threads = this.fallback ? 1 : this.want;
    if (this.resolveListen !== null) this.resolveListen();
  }

          fail(error       )       {
    if (this.settled) return;
    this.settled = true;
    for (let i = 0; i < this.workers.length; i++) {
      if (this.alive[i] === true) void this.workers[i] .terminate();
    }
    if (this.rejectListen !== null) this.rejectListen(error);
  }

          error(index        , error       )       {
    if (this.fallback && index !== this.chosen) return;
    if (this.settled) console.error("[server] worker " + String(index) + " failed: " + error.message);
    this.fail(error);
  }

          exited(index        )       {
    if (this.alive[index] !== true) return;
    this.alive[index] = false;
    this.remaining--;
    if (this.remaining === 0 && this.wake !== null) this.wake();
    if (!this.settled && !(this.fallback && index !== this.chosen)) {
      this.fail(new Error("worker " + String(index) + " exited before listening"));
    }
  }

  close()                {
    if (this.closing !== null) return this.closing;
    this.closing = this.stop();
    return this.closing;
  }

          async stop()                {
    for (let i = 0; i < this.workers.length; i++) {
      if (this.alive[i] === true) this.workers[i] .postMessage({ type: "close" });
    }
    const drained = this.remaining === 0
      ? Promise.resolve()
      : new Promise      ((resolve            ) => {
          this.wake = resolve;
        });
    const timeout = new Promise      ((resolve            ) => {
      const timer = setTimeout(() => resolve(), this.grace);
      timer.unref();
    });
    await Promise.race([drained, timeout]);
    for (let i = 0; i < this.workers.length; i++) {
      if (this.alive[i] === true) await this.workers[i] .terminate();
    }
  }
}

/** Spawns `threads` workers on one explicit port through the app's `spawn`, and resolves once each listens. */
export const serveThreads = async (options                )                         => {
  if (!Number.isInteger(options.threads) || options.threads < 1) throw new Error("serveThreads needs a thread count of at least 1");
  if (!Number.isInteger(options.port) || options.port <= 0) throw new Error("serveThreads needs an explicit port");
  const threads = new Threads(options);
  await threads.start();
  if (options.signals === true) {
    const stop = ()       => {
      threads.close().then(() => process.exit(0));
    };
    process.once("SIGTERM", stop);
    process.once("SIGINT", stop);
  }
  return threads;
};

/** Serves `app` in a worker on the primary's port with `reusePort`, until its `close` message. */
export const serveWorker = async (app     , options                     = {})                => {
  const port = parentPort;
  if (port === null) throw new Error("serveWorker runs in a worker thread");
  let server                    = null;
  let starting = false;
  let stopping = false;
  let resolveDone                      = null;
  const done = new Promise      ((resolve            ) => {
    resolveDone = resolve;
  });

  const stop = async ()                => {
    if (stopping) return;
    stopping = true;
    const current = server;
    server = null;
    if (current !== null) await current.close();
    port.postMessage({ type: "closed" });
    port.close();
    if (resolveDone !== null) resolveDone();
  };

  const start = async (settings                , reusePort         )                => {
    if (server !== null || starting || stopping) return;
    starting = true;
    try {
      server = await serve(app, {
        port: settings.port,
        host: settings.hostName,
        sockets: settings.sockets ?? undefined,
        grace: settings.grace,
        reusePort,
      });
      starting = false;
      port.postMessage({ type: "listening" });
    } catch (error) {
      starting = false;
      port.postMessage({ type: "listen-error", code: codeOf(error), message: messageOf(error) });
    }
  };

  port.on("message", (message         ) => {
    if (typeof message !== "object" || message === null) return;
    const record = message                 ;
    const type = typeof record.type === "string" ? record.type : "";
    if (type === "serve") {
      const settings = settingsOf(record);
      if (settings !== null) void start(settings, true);
    } else if (type === "fallback") {
      const settings = settingsOf(record);
      if (settings !== null) void start(settings, false);
    } else if (type === "close") {
      void stop();
    }
  });

  const data = typeof workerData === "object" && workerData !== null ? (workerData                  ) : {};
  const combined                 = {
    port: options.port ?? data.port,
    hostName: options.host ?? data.hostName ?? data.host,
    grace: options.grace ?? data.grace,
    sockets: options.sockets ?? data.sockets,
  };
  const initial = settingsOf(combined);
  if (initial !== null) void start(initial, true);
  await done;
};
