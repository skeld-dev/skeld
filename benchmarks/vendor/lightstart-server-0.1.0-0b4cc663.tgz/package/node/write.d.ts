/**
 * @file A `Reply` written out through a node `ServerResponse`, in one `writeHead` with the headers
 * as a flat list (so every `set-cookie` is its own line). A whole body gets its `content-length`
 * and goes out with `end`; a streamed one goes out chunked and stops once the client has gone; a
 * Fetch `Response` is copied out the same way, its body read chunk by chunk. A HEAD, a 204, a 304
 * and a 1xx carry no body. A write waits while the socket's buffer is full, polling
 * `writableNeedDrain` rather than listening for `drain`, since scriptc lowers neither a response's
 * `drain` nor removing a listener and a listener per wait would pile up on a keep-alive socket;
 * natively the runtime buffers a response's writes itself and the socket never reports full. A
 * websocket is accepted on the server's `upgrade` event (`socket.ts`), never here: an `upgrade`
 * reply that reaches a response is answered 501.
 */
import type { ServerResponse } from "node:http";
import { Reply, Writer } from "../reply.js";
export declare class NodeWriter extends Writer {
    private readonly res;
    constructor(res: ServerResponse);
    write(chunk: string | Uint8Array): Promise<void>;
    /** Resolves once the socket's buffer has room again, or the client has gone. */
    private settle;
}
/** Writes `reply` as the answer to a request made with `method`. */
export declare const writeReply: (res: ServerResponse, reply: Reply, method: string) => Promise<void>;
