/**
 * @file Several cores for the node adapter: `serveThreads` spawns workers the app names, waits for
 * each to listen on one explicit port with kernel-balanced `reusePort`, and closes them together;
 * `serveWorker` is the worker side, serving an app on that port and answering the primary's
 * settings, fallback and close messages. The primary never listens. The app writes the spawn
 * because scriptc needs `new Worker(new URL("./worker.js", import.meta.url))` in its own module,
 * a URL handed to a library refused with SC2020. Where the kernel has no balanced `reusePort`
 * (`ENOTSUP` or `EOPNOTSUPP`, as on macOS) one worker serves without it, and a warning says so.
 * Messages are plain records: a class instance loses its methods across threads.
 */
import { Worker } from "node:worker_threads";
import type { App } from "../app.js";
import type { SocketOptions } from "./socket.js";
/** What `serveThreads` starts: the explicit port, how many workers listen, and how to stop them. */
export interface ThreadsServer {
    readonly port: number;
    readonly threads: number;
    close(): Promise<void>;
}
/** The primary's settings: an explicit port, the workers to spawn, and the app's own `spawn`. */
export interface ThreadsOptions {
    port: number;
    host?: string;
    threads: number;
    spawn: (index: number) => Worker;
    grace?: number;
    signals?: boolean;
}
/** What a worker serves, read from its options, `workerData`, or the primary's `serve` message. */
export interface ServeWorkerOptions {
    port?: number;
    host?: string;
    sockets?: SocketOptions;
    grace?: number;
}
/** Spawns `threads` workers on one explicit port through the app's `spawn`, and resolves once each listens. */
export declare const serveThreads: (options: ThreadsOptions) => Promise<ThreadsServer>;
/** Serves `app` in a worker on the primary's port with `reusePort`, until its `close` message. */
export declare const serveWorker: (app: App, options?: ServeWorkerOptions) => Promise<void>;
