import type { IncomingMessage, Server } from "node:http";
import type { Socket as NetSocket } from "node:net";
import { Context } from "../context.js";
import { Reply } from "../reply.js";
import { Channel, Socket } from "../socket.js";
import { MessageIncoming, WorkTracker } from "./incoming.js";
import type { App } from "../app.js";
export interface SocketOptions {
    /** Milliseconds between keep-alive pings, 30 seconds by default; 0 sends none. */
    idle?: number;
    /** The most bytes one message may hold, 1 MiB by default. */
    maxMessage?: number;
}
/** An upgrade request on its bare connection: it carries no body, and the client has gone once the connection closes. */
export declare class UpgradeIncoming extends MessageIncoming {
    readonly socket: NetSocket;
    constructor(req: IncomingMessage, socket: NetSocket, tracker?: WorkTracker);
    text(_limit: number): Promise<string>;
    bytes(_limit: number): Promise<Uint8Array>;
}
/** An accepted websocket on node's connection. */
export declare class NodeSocket extends Socket {
    readonly stream: NetSocket;
    readonly channel: Channel;
    /** Whether anything arrived since the last keep-alive ping. */
    alive: boolean;
    private readonly owner;
    private readonly most;
    private pending;
    private parts;
    private partSize;
    private partKind;
    private shutCode;
    private shutReason;
    private deaf;
    private ended;
    constructor(stream: NetSocket, channel: Channel, most: number, owner: Sockets);
    /** Hands the socket to its channel and reads `head`, what arrived with the handshake, then the rest. */
    start(head: Buffer): void;
    send(data: string | Uint8Array): void;
    close(code?: number, reason?: string): void;
    /** A keep-alive ping; the pong, like anything the client sends, marks it alive. */
    ping(): void;
    /** Drops the connection with no close handshake: the channel hears 1006. */
    drop(): void;
    private write;
    /** Ends on a protocol fault: the close frame goes out and the connection with it. */
    private fault;
    private read;
    private frame;
    /** Once the connection closed: the channel hears the close that was sent, 1006 when none was. */
    private finish;
}
/** The websockets one server accepted, and how it accepts them. */
export declare class Sockets {
    readonly idle: number;
    readonly maxMessage: number;
    /** Where the work an upgrade request hands to `waitUntil` is counted. */
    readonly tracker: WorkTracker;
    private readonly live;
    private timer;
    constructor(options?: SocketOptions, tracker?: WorkTracker);
    /** How many are open. */
    get size(): number;
    /** `app`'s answer to the upgrade request `incoming`: true once answered, false (the connection untouched) when no route matches it. */
    answer(app: App, incoming: UpgradeIncoming, head: Buffer): Promise<boolean>;
    /** Answers the upgrade request `c` with `reply`: the handshake and the socket for an `upgrade` reply, anything else written as it is. */
    take(c: Context, reply: Reply, head: Buffer): void;
    /** Drops a socket that closed. */
    forget(socket: NodeSocket): void;
    private beat;
    /** Closes every open socket, 1001 by default. */
    close(code?: number, reason?: string): void;
}
/** Takes every upgrade request `server` receives to `app`; one no route matches is answered with the app's not-found reply. */
export declare const acceptUpgrades: (server: Server, app: App, sockets?: Sockets) => Sockets;
