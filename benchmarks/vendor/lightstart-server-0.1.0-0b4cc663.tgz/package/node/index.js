/**
 * @file The node adapter, for node and for a binary scriptc compiled (whose `node:http` is its own
 * native server): `serve(app, options)` listens and answers every request with `app.dispatch`.
 * Work handed to `waitUntil` runs after the reply and is counted, so `close()` stops accepting,
 * lets the open connections finish (dropping them once `grace` runs out) and waits for that work;
 * with `signals`, a SIGTERM or SIGINT closes the server that way and exits. A handler that throws
 * past the app's error handler, or a reply that cannot be written, ends that response with a bare
 * 500 or drops the connection once the headers are out. With `sockets`, an upgrade request goes to
 * the app too, and a route's `upgrade(c, channel)` becomes a websocket (`socket.ts`); `close()`
 * closes the open ones 1001 first.
 */
import { createServer,                                                        } from "node:http";
import { Context } from "../context.js";
import { Reply } from "../reply.js";
import { NodeIncoming, WorkTracker } from "./incoming.js";
import { Sockets, acceptUpgrades,                    } from "./socket.js";
import { writeReply } from "./write.js";
                                     

export { MessageIncoming, NodeIncoming, WorkTracker } from "./incoming.js";
export { NodeSocket, Sockets, UpgradeIncoming, acceptUpgrades,                    } from "./socket.js";
export { NodeCrypto } from "./crypto.js";
export { NodeWriter, writeReply } from "./write.js";
export { serveThreads, serveWorker,                                                                  } from "./threads.js";

                               
                                                                                               
                
                                                         
                
                                                                             
                
                                                                                                    
                      
                                              
                    
                                                                                                   
                 
                                                                                                    
                          
 

const failed = (app     , res                , error         )       => {
  app.logger.error("the reply could not be written", error);
  if (res.headersSent) {
    res.destroy();
    return;
  }
  const head           = ["content-type", "text/plain; charset=utf-8", "content-length", "14"];
  res.writeHead(500, head);
  res.end("internal error");
};

export class NodeServer extends WorkTracker {
           app     ;
           server        ;
  /** The port it listens on, 0 on a Unix socket. */
  port = 0;
  /** The websockets it accepted, null unless it takes them. */
  sockets                 = null;
                   grace        ;
          pending = 0;
          drained                      = null;
          closing                       = null;

  constructor(app     , grace        ) {
    super();
    this.app = app;
    this.grace = grace;
    this.server = createServer((req                 , res                ) => {
      this.answer(req, res);
    });
  }

          answer(req                 , res                )       {
    const c = new Context(new NodeIncoming(req, res, this));
    this.app.dispatch(c).then(
      (reply       ) => writeReply(res, reply, c.method).catch((error         ) => failed(this.app, res, error)),
      (error         ) => failed(this.app, res, error),
    );
  }

  track(work               )       {
    this.pending++;
    work.then(() => {
      this.pending--;
      if (this.pending === 0 && this.drained !== null) this.drained();
    });
  }

  /** Stops accepting, waits for open connections and pending work (at most `grace` ms), and resolves once closed. */
  close()                {
    if (this.closing !== null) return this.closing;
    if (this.sockets !== null) this.sockets.close();
    const server = this.server;
    const grace = this.grace;
    const closed = new Promise      ((resolve            ) => {
      server.close(() => resolve());
      server.closeIdleConnections();
    });
    const work = this.pending === 0
      ? Promise.resolve()
      : new Promise      ((resolve            ) => {
          this.drained = resolve;
        });
    const timeout = new Promise      ((resolve            ) => {
      const timer = setTimeout(() => {
        server.closeAllConnections();
        resolve();
      }, grace);
      timer.unref();
    });
    const closing = Promise.race([Promise.all([closed, work]).then(() => {}), timeout]);
    this.closing = closing;
    return closing;
  }
}

const listening = (node            , options              )                =>
  new Promise((resolve            , reject                        ) => {
    const server = node.server;
    let listened = false;
    server.once("error", (error       ) => {
      if (!listened) reject(error);
    });
    const ready = ()       => {
      listened = true;
      if (options.path === undefined) {
        /* @ts-expect-error */
        node.port = server.address().port;
      }
      resolve();
    };
    if (options.path !== undefined) server.listen(options.path, ready);
    else if (options.reusePort === true) {
      if (options.host !== undefined) server.listen({ port: options.port !== undefined ? options.port : 3000, host: options.host, reusePort: true }, ready);
      else server.listen({ port: options.port !== undefined ? options.port : 3000, reusePort: true }, ready);
    } else if (options.host !== undefined) server.listen(options.port ?? 3000, options.host, ready);
    else server.listen(options.port ?? 3000, ready);
  });

/** Listens with `app` and answers once listening. */
export const serve = async (app     , options               = {})                      => {
  if (options.reusePort === true) {
    if (options.path !== undefined) throw new Error("reusePort cannot be used with path");
    if (options.port === undefined || options.port === 0) throw new Error("reusePort needs an explicit port other than 0");
  }
  app.build();
  const node = new NodeServer(app, options.grace ?? 10000);
  if (options.sockets !== undefined) node.sockets = acceptUpgrades(node.server, app, new Sockets(options.sockets, node));
  await listening(node, options);
  if (options.signals === true) {
    const stop = ()       => {
      node.close().then(() => process.exit(0));
    };
    process.once("SIGTERM", stop);
    process.once("SIGINT", stop);
  }
  return node;
};
