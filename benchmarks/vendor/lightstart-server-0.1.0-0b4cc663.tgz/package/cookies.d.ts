/**
 * @file Cookies on the request and on the reply. `parseCookies` reads a `Cookie` header once,
 * following RFC 6265: names and values split on `;`, one pair of surrounding quotes stripped from
 * a value, percent-decoded when it decodes, the raw value kept when it does not, and the first
 * occurrence of a name winning. `setCookie` and `clearCookie` append a `set-cookie` value, so two
 * cookies on one reply stay two headers; `Context.cookie` and `Context.cookies` read with
 * `parseCookies`.
 *
 * The defaults are `Path=/`, `HttpOnly`, `SameSite=Lax`, and `Secure` only when the request came
 * over https (`secure: "auto"`). The reply does not know the request, so an auto cookie is left
 * for `App.finish` to settle, which appends `; Secure` when the context's protocol is https, before the reply hooks run (so a hook removing a header cannot shift which value is settled) and again after them, for cookies a hook set. A reply with no auto cookie keeps a null list and costs that one check. A
 * reply written without going through an `App` (an adapter calling `writeReply` directly) leaves
 * its auto cookies without `Secure`.
 */
import { Reply } from "./reply.js";
/** What `setCookie` and `clearCookie` write. */
export interface CookieOptions {
    /** Lifetime in seconds (written `Max-Age`). */
    maxAge?: number;
    /** The expiry instant (written `Expires`). */
    expires?: Date;
    /** The path the cookie covers; "/" by default. */
    path?: string;
    /** The domain the cookie covers; the request's host by default. */
    domain?: string;
    /** `HttpOnly` unless false. */
    httpOnly?: boolean;
    /** `Secure`; "auto" (the default) writes it only when the request is https. */
    secure?: boolean | "auto";
    /** `SameSite`; "Lax" by default. */
    sameSite?: "Strict" | "Lax" | "None";
    /** `Partitioned`, for a cookie in a partitioned (CHIPS) storage. */
    partitioned?: boolean;
}
/** The cookies of a `Cookie` header, the first occurrence of a name winning; empty and malformed pairs are skipped. */
export declare const parseCookies: (header: string | null) => Map<string, string>;
/** Appends `name=value` to `reply`'s `set-cookie` headers, with the options given, and answers the reply. */
export declare const setCookie: (reply: Reply, name: string, value: string, options?: CookieOptions) => Reply;
/** Expires `name` on the client: an empty value, `Max-Age=0`, and the same path and domain. */
export declare const clearCookie: (reply: Reply, name: string, options?: CookieOptions) => Reply;
