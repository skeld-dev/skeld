import { HeaderList } from "../headers.js";
import { Incoming } from "../incoming.js";
import { Reply } from "../reply.js";
import type { App } from "../app.js";
/** A request's parts, every one optional. */
export interface MemoryInit {
    headers?: Record<string, string>;
    body?: string;
    address?: string;
    protocol?: string;
    env?: unknown;
}
export declare class MemoryIncoming extends Incoming {
    private readonly verb;
    private readonly url;
    readonly headers: HeaderList;
    private readonly body;
    private readonly address;
    private readonly scheme;
    private readonly bindings;
    readonly pending: Promise<void>[];
    readonly controller: AbortController;
    constructor(method: string, target: string, init: MemoryInit);
    method(): string;
    target(): string;
    header(name: string): string | null;
    headerPairs(): string[];
    text(limit: number): Promise<string>;
    bytes(limit: number): Promise<Uint8Array>;
    remoteAddress(): string;
    protocol(): string;
    signal(): AbortSignal;
    abort(_reason: string): void;
    env(): unknown;
    waitUntil(work: Promise<void>): void;
}
/** Dispatches one request to `app` and answers its reply once the work it handed to `waitUntil` is done. */
export declare const request: (app: App, method: string, target: string, init?: MemoryInit) => Promise<Reply>;
/** The reply's body as text, whichever kind it carries: a stream is run to its end. */
export declare const bodyOf: (reply: Reply) => Promise<string>;
/** The client end of a websocket `connect` made: `reply` is the upgrade's answer, 101 when a route accepted it. */
export declare class MemoryClient {
    readonly reply: Reply;
    readonly received: string[];
    readonly receivedBytes: Uint8Array[];
    /** The close code once closed by either end, 0 while open. */
    code: number;
    reason: string;
    private socket;
    constructor(reply: Reply);
    /** Whether the upgrade was accepted and neither end has closed. */
    get open(): boolean;
    /** A text message for a string, a binary one for bytes, delivered to the channel before this returns. */
    send(data: string | Uint8Array): void;
    close(code?: number, reason?: string): void;
}
/** Makes the upgrade request `target` to `app`: the client end of the websocket, `open` when a route accepted it. */
export declare const connect: (app: App, target: string, init?: MemoryInit) => Promise<MemoryClient>;
