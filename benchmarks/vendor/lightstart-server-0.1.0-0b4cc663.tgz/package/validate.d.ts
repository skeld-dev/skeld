import { Key } from "./key.js";
import type { Middleware } from "./router.js";
/** The typed path parameters a route's `validate` accepted: a field name to its value. */
export declare const PARAMS: Key<Map<string, unknown>>;
/** The typed query values a route's `validate` accepted: a field name to its value. */
export declare const QUERY: Key<Map<string, unknown>>;
/** The typed body a route's `validate` accepted: a field name to its value. */
export declare const BODY: Key<Map<string, unknown>>;
/** One light model field descriptor, as far as this validator reads it. */
export interface FieldDescriptor {
    $type?: string;
    required?: boolean;
    defaultValue?: unknown;
    validator?: unknown;
    format?: unknown;
    relationship?: string;
    belongs?: boolean;
    many?: boolean;
    fieldType?: string;
    [key: string]: unknown;
}
/** A record of field descriptors: a model's schema, or the fields a request carries. */
export type FieldSchema = Record<string, FieldDescriptor>;
/** What a route validates: any of its parameters, its query and its body. */
export interface ValidateSchemas {
    params?: FieldSchema;
    query?: FieldSchema;
    body?: FieldSchema;
}
/**
 * A route's middleware over light's model field descriptors: `validate({ query: { limit: { $type:
 * "number" } } })` coerces `?limit=10` to `10`, or answers 400 `{ error: "invalid request", fields:
 * { "query.limit": "must be a number" } }`. On success the typed values are on the context under
 * `PARAMS`, `QUERY` and `BODY`.
 */
export declare const validate: (schemas: ValidateSchemas) => Middleware;
