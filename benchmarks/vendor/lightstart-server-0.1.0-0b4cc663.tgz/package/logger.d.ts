/**
 * @file Where the server's own complaints go: a handler's unexpected error, work after a reply that
 * failed, a reply that could not be written. The default writes to stderr with the stack; a host
 * replaces it with `app.logTo(logger)` to ship them elsewhere, a test to read them back.
 */
export declare class Logger {
    /** One problem: what failed, then the error itself. */
    error(what: string, error: unknown): void;
}
/** Keeps every problem as "what: message", for a test to read. */
export declare class MemoryLogger extends Logger {
    readonly lines: string[];
    error(what: string, error: unknown): void;
}
