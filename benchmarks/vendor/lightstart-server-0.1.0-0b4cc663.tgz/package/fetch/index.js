/**
 * @file The fetch adapter, for every runtime that hands a handler a Fetch `Request` and takes a
 * `Response` back: Cloudflare Workers and Pages (`export default { fetch: toFetch(app) }`), Bun
 * (`Bun.serve({ fetch: toFetch(app) })`), Deno (`Deno.serve((request) => handler(request))`, since
 * Deno's second argument is not an `env`), and any host built on them. The request is read where
 * it lies: headers by name, the body when asked for (counted against the limit as it streams in),
 * the original `Request` handed back to a handler that wants one. Work given to `waitUntil` goes to
 * the platform's (a Worker's `ctx.waitUntil`, which keeps it alive after the reply) and otherwise
 * runs on its own. A reply becomes a `Response`: a whole body as it is, a streamed one through a
 * `ReadableStream`, a `Response` the handler made passed on as it is, with only the headers the
 * reply gained (a plugin's CORS grant, security headers) added where it has none of its own. Websockets are not taken
 * here yet (each runtime upgrades its own way): an `upgrade` reply is answered 501.
 */
import { Context } from "../context.js";
import { HttpError } from "../errors.js";
import { Incoming } from "../incoming.js";
import { Reply, Writer } from "../reply.js";
import { unaccepted } from "../socket.js";
                                     

/** The slice of a platform's per-request context the adapter uses: a Worker's `ExecutionContext`. */
                                
                                          
 

                               
                                                                                                                         
                                         
 

const tooLarge = (limit        )            => new HttpError(413, "the body is larger than " + String(limit) + " bytes");

const readAll = async (request         , limit        )                      => {
  const declared = request.headers.get("content-length");
  if (declared !== null && Number(declared) > limit) throw tooLarge(limit);
  const body = request.body;
  if (body === null) return new Uint8Array(0);
  const reader = body.getReader();
  const chunks               = [];
  let size = 0;
  for (;;) {
    const next = await reader.read();
    if (next.done) break;
    size += next.value.length;
    if (size > limit) {
      await reader.cancel();
      throw tooLarge(limit);
    }
    chunks.push(next.value);
  }
  if (chunks.length === 1) return chunks[0] ;
  const out = new Uint8Array(size);
  let at = 0;
  for (const chunk of chunks) {
    out.set(chunk, at);
    at += chunk.length;
  }
  return out;
};

export class FetchIncoming extends Incoming {
           request         ;
                   bindings         ;
                   platform                      ;
                   address        ;
                   scheme        ;
                   authority        ;
                   path        ;
          controller                         = null;

  constructor(request         , bindings         , platform                      , address        ) {
    super();
    this.request = request;
    this.bindings = bindings;
    this.platform = platform;
    this.address = address;
    const url = request.url;
    const colon = url.indexOf(":");
    this.scheme = colon < 0 ? "http" : url.slice(0, colon);
    const start = url.indexOf("//");
    const slash = start < 0 ? -1 : url.indexOf("/", start + 2);
    const query = start < 0 ? -1 : url.indexOf("?", start + 2);
    const end = slash >= 0 ? slash : query >= 0 ? query : url.length;
    this.authority = start < 0 ? "" : url.slice(start + 2, end);
    if (slash >= 0) this.path = url.slice(slash);
    else this.path = query < 0 ? "/" : "/" + url.slice(query);
  }

  method()         {
    return this.request.method;
  }

  target()         {
    return this.path;
  }

  header(name        )                {
    return this.request.headers.get(name);
  }

  headerPairs()           {
    const out           = [];
    this.request.headers.forEach((value        , name        ) => {
      out.push(name);
      out.push(value);
    });
    return out;
  }

  text(limit        )                  {
    return readAll(this.request, limit).then((body            ) => new TextDecoder().decode(body));
  }

  bytes(limit        )                      {
    return readAll(this.request, limit);
  }

  remoteAddress()         {
    return this.address;
  }

           host()         {
    return this.authority;
  }

  protocol()         {
    return this.scheme;
  }

          linked()                  {
    if (this.controller !== null) return this.controller;
    const controller = new AbortController();
    this.controller = controller;
    if (this.request.signal.aborted) controller.abort();
    else this.request.signal.addEventListener("abort", () => controller.abort());
    return controller;
  }

  signal()              {
    return this.linked().signal;
  }

           abort(_reason        )       {
    this.linked().abort();
  }

           env()          {
    return this.bindings;
  }

  waitUntil(work               )       {
    if (this.platform !== null) this.platform.waitUntil(work);
  }

           original()                 {
    return this.request;
  }
}

class StreamWriter extends Writer {
                   deliver                             ;
                   encoder = new TextEncoder();

  constructor(deliver                             ) {
    super();
    this.deliver = deliver;
  }

  write(chunk                     )                {
    if (!this.closed) this.deliver(typeof chunk === "string" ? this.encoder.encode(chunk) : chunk);
    return Promise.resolve();
  }

  stop()       {
    this.closed = true;
  }
}

const bodiless = (method        , status        )          => method === "HEAD" || status === 204 || status === 304 || (status >= 100 && status < 200);

const withReplyHeaders = (response          , reply       )           => {
  const names = reply.headers.names;
  if (names.length === 0) return response;
  const headers = new Headers(response.headers);
  for (let i = 0; i < names.length; i++) {
    const name = names[i] ;
    if (name === "set-cookie" || !headers.has(name)) headers.append(name, reply.headers.values[i] );
  }
  return new Response(response.body, { status: response.status, statusText: response.statusText, headers: headers });
};

/** `reply` as the `Response` to a request made with `method`; a `Response` the handler made keeps its own headers and gains the reply's others (a plugin's CORS grant, security headers). */
export const toResponse = (reply       , method        )           => {
  if (reply.response !== null) return withReplyHeaders(reply.response, reply);
  if (reply.channel !== null) return toResponse(unaccepted(), method);
  const headers = new Headers();
  const names = reply.headers.names;
  const values = reply.headers.values;
  for (let i = 0; i < names.length; i++) headers.append(names[i] , values[i] );
  const init = { status: reply.status, headers };
  if (bodiless(method, reply.status)) return new Response(null, init);
  if (reply.text !== null) return new Response(reply.text, init);
  if (reply.bytes !== null) return new Response(reply.bytes, init);
  const body = reply.stream;
  if (body === null) return new Response(null, init);
  const writers                 = [];
  const source = new ReadableStream            ({
    start(controller                                             )       {
      const writer = new StreamWriter((chunk            ) => controller.enqueue(chunk));
      writers.push(writer);
      body(writer).then(
        () => {
          if (!writer.closed) controller.close();
        },
        (error         ) => {
          if (!writer.closed) controller.error(error);
        },
      );
    },
    cancel()       {
      for (const writer of writers) writer.stop();
    },
  });
  return new Response(source, init);
};

/** A Fetch handler for `app`: `(request, env?, ctx?) => Promise<Response>`, the shape a Worker exports. */
export const toFetch = (app     , options               = {}) => {
  app.build();
  const address = options.address;
  return async (request         , env          , ctx                )                    => {
    const incoming = new FetchIncoming(request, env ?? null, ctx ?? null, address === undefined ? "" : address(request));
    const c = new Context(incoming);
    return toResponse(await app.dispatch(c), c.method);
  };
};
