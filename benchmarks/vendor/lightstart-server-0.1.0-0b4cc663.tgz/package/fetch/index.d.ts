import { Incoming } from "../incoming.js";
import { Reply } from "../reply.js";
import type { App } from "../app.js";
/** The slice of a platform's per-request context the adapter uses: a Worker's `ExecutionContext`. */
export interface FetchPlatform {
    waitUntil(work: Promise<unknown>): void;
}
export interface FetchOptions {
    /** The client's address for a request, "" by default: on Workers, `(r) => r.headers.get("cf-connecting-ip") ?? ""`. */
    address?: (request: Request) => string;
}
export declare class FetchIncoming extends Incoming {
    readonly request: Request;
    private readonly bindings;
    private readonly platform;
    private readonly address;
    private readonly scheme;
    private readonly authority;
    private readonly path;
    private controller;
    constructor(request: Request, bindings: unknown, platform: FetchPlatform | null, address: string);
    method(): string;
    target(): string;
    header(name: string): string | null;
    headerPairs(): string[];
    text(limit: number): Promise<string>;
    bytes(limit: number): Promise<Uint8Array>;
    remoteAddress(): string;
    host(): string;
    protocol(): string;
    private linked;
    signal(): AbortSignal;
    abort(_reason: string): void;
    env(): unknown;
    waitUntil(work: Promise<void>): void;
    original(): Request | null;
}
/** `reply` as the `Response` to a request made with `method`; a `Response` the handler made keeps its own headers and gains the reply's others (a plugin's CORS grant, security headers). */
export declare const toResponse: (reply: Reply, method: string) => Response;
/** A Fetch handler for `app`: `(request, env?, ctx?) => Promise<Response>`, the shape a Worker exports. */
export declare const toFetch: (app: App, options?: FetchOptions) => (request: Request, env?: unknown, ctx?: FetchPlatform) => Promise<Response>;
