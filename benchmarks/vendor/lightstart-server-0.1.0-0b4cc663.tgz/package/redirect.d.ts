/**
 * @file A redirect to a target the request supplied (a `?next=` after sign-in), refused unless it
 * stays on this origin. A path (`/x`, `/x?y#z`) or an absolute `http(s)://` URL whose host and
 * port are `c.host`'s (what a trusted proxy forwarded included) is allowed and written as it
 * arrived; a protocol-relative target, a backslash, another scheme, leading whitespace or a control
 * character, userinfo, another host and an empty target answer the fallback instead.
 */
import type { Context } from "./context.js";
import type { Reply } from "./reply.js";
/**
 * A redirect to `target` when it stays on this origin, else one to `fallback`: `safeRedirect(c,
 * c.query("next") ?? "/")` after sign-in. A same-origin path or an absolute `http(s)` URL to
 * `c.host` (a trusted proxy's word included) is allowed; anything else answers `fallback`.
 */
export declare const safeRedirect: (c: Context, target: string, fallback?: string, status?: number) => Reply;
