/** `origin`'s `host[:port]`, lower-cased, or null when it is not a plain http(s) origin. */
export declare const authorityOf: (origin: string) => string | null;
