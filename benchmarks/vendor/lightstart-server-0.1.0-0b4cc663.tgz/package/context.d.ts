import { Incoming } from "./incoming.js";
import { Key } from "./key.js";
import { Logger } from "./logger.js";
/** The default most bytes a request body may hold: 1 MiB. */
export declare const DEFAULT_BODY_LIMIT = 1048576;
export declare class Context {
    readonly incoming: Incoming;
    readonly method: string;
    readonly path: string;
    /** The query as it arrived, without the "?": "" when there is none. */
    readonly search: string;
    /** The route pattern that matched (`/carts/:id`), "" before routing or when none did. */
    route: string;
    /** Where a failure of work after the reply is logged: the app's logger once it handles the request. */
    logger: Logger;
    /** The most bytes the body may hold; a plugin or a middleware may raise or lower it before the read. */
    limit: number;
    paramNames: string[];
    paramValues: string[];
    private queryNames;
    private queryValues;
    private cookiesRead;
    private bearerDone;
    private bearerToken;
    private sameOriginRead;
    private formRead;
    private acceptRanges;
    private slots;
    private textRead;
    private bytesRead;
    private forwardedProtocol;
    private forwardedHost;
    private forwardedAddress;
    constructor(incoming: Incoming);
    /** The request header `name`, repeated values joined with ", ", or null. */
    header(name: string): string | null;
    /** The path parameter `name` (`:id` in the pattern, `*` for the wildcard's rest), or null. */
    param(name: string): string | null;
    /** The first value of the query parameter `name`, decoded, or null. */
    query(name: string): string | null;
    /** Every value of the query parameter `name`, in order. */
    queryAll(name: string): string[];
    private parsedQuery;
    /** The value of the cookie `name`, or null: the `Cookie` header parsed on the first call. */
    cookie(name: string): string | null;
    /** Every cookie of the request, the first occurrence of a name winning; parsed once. */
    cookies(): Map<string, string>;
    /** The token of an `Authorization: Bearer <token>` header, trimmed, or null. */
    bearer(): string | null;
    /** Whether the request is same-origin or came from no browser: `Sec-Fetch-Site`, then `Origin` against `host`. */
    sameOrigin(): boolean;
    private isSameOrigin;
    /** The urlencoded form body, every value of a repeated name in order; read once, within `limit`. */
    form(): Promise<Map<string, string[]>>;
    private readForm;
    /** The best of `types` for the `Accept` header, or null; the first type when there is no header. */
    accepts(...types: string[]): string | null;
    private parsedAccept;
    /** "http" or "https": what the client asked for, a trusted proxy's word over the connection's. */
    get protocol(): string;
    /** The host the client asked for: a trusted proxy's word, else the request's own, else "localhost". */
    get host(): string;
    /** The client's address: a trusted proxy's word, else the peer that connected. */
    get ip(): string;
    /** The URL the client asked for, as text. */
    get url(): string;
    /** What a trusted proxy forwarded; an empty string leaves that part as the connection said. */
    forwarded(protocol: string, host: string, address: string): void;
    /** The platform's bindings (a Worker's `env`), null where there are none. */
    get env(): unknown;
    /** Aborted when the client goes away before the reply is done. */
    get signal(): AbortSignal;
    /** The body as text, read once; a later read answers the same text. */
    text(): Promise<string>;
    /** The body as bytes, read once. */
    bytes(): Promise<Uint8Array>;
    /** The body parsed as JSON, `unknown` until narrowed; an empty or malformed body is a 400. */
    json(): Promise<unknown>;
    /** The value a middleware set for `key`, undefined when none did. */
    get<T>(key: Key<T>): T | undefined;
    /** Sets the value of `key` for the rest of this request. */
    set<T>(key: Key<T>, value: T): void;
    /** Hands the platform work that may finish after the reply; a rejection is logged, never answered. */
    waitUntil(work: Promise<unknown>): void;
    /** The request as a Fetch `Request`: the platform's own where it spoke Fetch, else one built with the body read. */
    request(): Promise<Request>;
}
