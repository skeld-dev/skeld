import type { Middleware } from "./router.js";
/** Answers 504 when the rest of the chain has not answered within `ms`, aborting `c.signal`. */
export declare const timeout: (ms: number, message?: string) => Middleware;
