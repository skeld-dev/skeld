/**
 * @file Routes and how a request finds one. A pattern is `/`-separated segments: a literal, a
 * `:name` parameter (one non-empty segment), or a trailing `*` (the rest, which may be empty, so
 * `/files/*` also answers `/files`). Patterns with no parameter sit in one `Map` by their text, so
 * most requests are answered by one lookup; the others sit in a trie of segments. A literal segment
 * is tried before a parameter and a parameter before a wildcard, deeper wildcards before shallower
 * ones, and the walk backs up when a branch has nothing for the method, so a specific route that
 * lacks it never hides a broader one that has it. A path some route matches under another method
 * answers 405 with those methods; a path nothing matches answers null. HEAD falls back to GET,
 * and a route for `ALL` answers every method its pattern has no route of its own for.
 */
import { Context } from "./context.js";
import { Reply } from "./reply.js";
export type Handler = (c: Context) => Reply | Promise<Reply>;
/** Runs the rest of the chain (the later middleware, then the handler) and answers its reply. */
export type Next = () => Promise<Reply>;
/** Runs around the handler: may answer without calling `next`, or change what `next` answered. */
export type Middleware = (c: Context, next: Next) => Promise<Reply>;
/** The method a route registered with `all` is filed under. */
export declare const ALL = "ALL";
export declare class Route {
    readonly method: string;
    readonly pattern: string;
    /** The parameter names in the order their segments appear, `*` last for a wildcard. */
    readonly names: string[];
    readonly handlerFn: Handler;
    /** The middleware this route runs, outermost first: the app's, then its own. Set when the app is built. */
    chain: Middleware[];
    constructor(method: string, pattern: string, handlerFn: Handler, chain: Middleware[]);
}
/** The routes of one pattern shape, one per method. */
export declare class RouteSet {
    readonly routes: Route[];
    add(route: Route): void;
    /** The route answering `method`: its own, a GET for a HEAD, else the pattern's `ALL` route. */
    find(method: string): Route | null;
    methods(): string[];
}
/** Refuses a pattern that cannot match: the reason, or "" when it is well formed. */
export declare const patternProblem: (pattern: string) => string;
export declare class Router {
    private readonly exact;
    private readonly root;
    add(route: Route): void;
    /** The route for the context's method and path, with its parameters written onto the context; null when none answers. */
    find(c: Context): Route | null;
    /** The methods some route answers for `path`: empty when nothing matches it (a 404), else the 405's `Allow`. */
    allowed(path: string): string[];
    /** `pos` is where the next segment starts, -1 once the path is used up exactly at `node`. */
    private walk;
    private collect;
}
