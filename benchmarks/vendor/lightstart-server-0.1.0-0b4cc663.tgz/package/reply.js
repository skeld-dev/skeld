/**
 * @file What a handler answers: a status, a `HeaderList`, and at most one body, each kind in a field
 * of its own so an adapter reads the one that is set without narrowing a union. `text` and `bytes`
 * are whole bodies an adapter frames with a `content-length`; `stream` is written chunk by chunk
 * through a `Writer` (node's `res.write`, a `ReadableStream` on fetch runtimes); `response` is a
 * Fetch `Response` a fetch adapter passes on untouched and the node adapter copies out; `channel`
 * is the websocket an `upgrade` accepts (`socket.ts`). The
 * builders below are how a handler makes one: `return json({ ok: true })`.
 */
import { HeaderList } from "./headers.js";
                                           

/**
 * Where a streamed body goes. `write` resolves once the chunk may be followed by the next (node's
 * backpressure); after the client has gone `closed` is true and writes are dropped.
 */
export          class Writer {
  closed = false;

                                                            
}

/** A streamed body: called once with the writer, the body ends when its promise settles. */
                                                        

export class Reply {
  status        ;
           headers             = new HeaderList();
  text                = null;
  bytes                    = null;
  stream                    = null;
  response                  = null;
  /** The websocket the request becomes, where the adapter takes one (`upgrade(c, channel)`). */
  channel                 = null;
  /** The route declined the request after its pattern matched: the app answers null, as for a path nothing matches (`pass()`). */
  passed = false;
  /** Indices in `headers` of the `set-cookie` values whose `Secure` is settled when the app finishes the reply (`cookies.ts`). */
  autoSecure                  = null;

  constructor(status        ) {
    this.status = status;
  }

  /** Sets a header and answers the reply, so a builder's result can be extended in one expression. */
  header(name        , value        )        {
    this.headers.set(name, value);
    return this;
  }
}

/** A JSON body: `data` stringified, with `application/json`. `data` is a record or an array, never a class instance. */
export const json = (data         , status = 200)        => {
  const reply = new Reply(status);
  reply.headers.appendLower("content-type", "application/json; charset=utf-8");
  reply.text = JSON.stringify(data);
  return reply;
};

/** `{ "error": message }` with `status` and `cache-control: no-store`: a refusal. */
export const fail = (message        , status        )        => {
  const reply = json({ error: message }, status);
  reply.headers.appendLower("cache-control", "no-store");
  return reply;
};

/** A plain text body. */
export const text = (body        , status = 200)        => {
  const reply = new Reply(status);
  reply.headers.appendLower("content-type", "text/plain; charset=utf-8");
  reply.text = body;
  return reply;
};

/** An HTML body. */
export const html = (body        , status = 200)        => {
  const reply = new Reply(status);
  reply.headers.appendLower("content-type", "text/html; charset=utf-8");
  reply.text = body;
  return reply;
};

/** A body of bytes with the content type given. */
export const bytes = (body            , type        , status = 200)        => {
  const reply = new Reply(status);
  reply.headers.appendLower("content-type", type);
  reply.bytes = body;
  return reply;
};

/** No body: a 204 by default, or a 304, a 201 with a `location`, a HEAD's answer. */
export const empty = (status = 204)        => new Reply(status);

/** A redirect to `location`, 302 unless told otherwise. */
export const redirect = (location        , status = 302)        => {
  const reply = new Reply(status);
  reply.headers.appendLower("location", location);
  return reply;
};

/** A streamed body of `type`: the adapter sends the headers, then whatever `body` writes, then ends. */
export const stream = (body            , type        , status = 200)        => {
  const reply = new Reply(status);
  reply.headers.appendLower("content-type", type);
  reply.stream = body;
  return reply;
};

/** Server-sent events over a streamed body: `send` writes one event, `comment` a line the client ignores (a keep-alive). */
export class EventSink {
           out        ;

  constructor(out        ) {
    this.out = out;
  }

  /** Whether the client has gone, after which nothing more is sent. */
  get closed()          {
    return this.out.closed;
  }

  /** One event: its data (each line its own `data:`), and an event name and an id when given. */
  send(data        , event = "", id = "")                {
    let frame = "";
    if (id !== "") frame += "id: " + id + "\n";
    if (event !== "") frame += "event: " + event + "\n";
    for (const line of data.split("\n")) frame += "data: " + line + "\n";
    return this.out.write(frame + "\n");
  }

  comment(text        )                {
    return this.out.write(": " + text + "\n\n");
  }
}

/**
 * An event stream: `sse(async (events) => { await events.send("hi") })`. Never cached, and marked
 * unbuffered for a proxy in front (nginx's `x-accel-buffering`), so each event reaches the client
 * when it is sent.
 */
export const sse = (body                                      )        => {
  const reply = stream((out        ) => body(new EventSink(out)), "text/event-stream; charset=utf-8");
  reply.headers.appendLower("cache-control", "no-cache");
  reply.headers.appendLower("x-accel-buffering", "no");
  return reply;
};

/**
 * A route declining a request its pattern matched, because what it serves is
 * decided per request (a model that may not exist, a file that may not be
 * there): `app.handle` answers null, so a host tries what sits behind the app,
 * and `app.dispatch` answers the not-found reply.
 */
export const pass = ()        => {
  const reply = new Reply(404);
  reply.passed = true;
  return reply;
};

/** A Fetch `Response` as a reply: passed on as it is where the adapter speaks Fetch, copied out where it does not. */
export const respond = (response          )        => {
  const reply = new Reply(response.status);
  reply.response = response;
  return reply;
};
