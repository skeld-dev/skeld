/**
 * @file A health route for a load balancer or an orchestrator: GET (and HEAD) `/health` by default,
 * answering `{ "ok": true }`, or `{ "ok": false }` with a 503 when the check given says the server
 * cannot serve (its database is gone, it is draining). Never cached.
 */
                                     
import { Plugin } from "../plugin.js";
import { Reply, json } from "../reply.js";

                                
                
                                                                              
                                 
 

export class Health extends Plugin {
           options               ;

  constructor(options                = {}) {
    super("health", []);
    this.options = options;
  }

  setup(app     )       {
    const check = this.options.check;
    app.get(this.options.path ?? "/health", async ()                 => {
      const ok = check === undefined ? true : await check().catch(() => false);
      return json({ ok }, ok ? 200 : 503).header("cache-control", "no-store");
    });
  }
}
