/**
 * @file A request id on every request and its reply: the incoming `x-request-id` when it is a
 * plausible id (at most 128 characters of letters, digits and `-_.:`), so a trace crosses the
 * proxy in front, else a new random UUID. A handler reads it with `c.get(REQUEST_ID)`; every reply
 * carries it back in the same header.
 */
                                     
import { Context } from "../context.js";
import { Key } from "../key.js";
import { Plugin } from "../plugin.js";
import { Reply } from "../reply.js";

export const REQUEST_ID = new Key        ("request id");

const PLAUSIBLE = /^[A-Za-z0-9\-_.:]{1,128}$/;

export class RequestId extends Plugin {
           header        ;

  constructor(header = "x-request-id") {
    super("request-id", []);
    this.header = header.toLowerCase();
  }

  setup(app     )       {
    const header = this.header;
    app.onRequest((c         )               => {
      const given = c.header(header);
      c.set(REQUEST_ID, given !== null && PLAUSIBLE.test(given) ? given : crypto.randomUUID());
      return null;
    });
    app.onReply((c         , reply       )       => {
      const id = c.get(REQUEST_ID);
      if (id !== undefined) reply.headers.set(header, id);
    });
  }
}
