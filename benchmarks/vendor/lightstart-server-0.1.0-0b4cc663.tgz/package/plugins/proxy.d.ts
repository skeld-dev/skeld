/**
 * @file Running behind a reverse proxy or a load balancer: `app.plugin(new TrustProxy({ trust: ["10.0.0.0/8"] }))`.
 * A request whose peer is a trusted proxy has its protocol, host and client address taken from
 * what the proxy forwarded (`Forwarded`, else `X-Forwarded-Proto`, `X-Forwarded-Host` and
 * `X-Forwarded-For`), so `c.protocol`, `c.host`, `c.url` and `c.ip` say what the client asked for
 * and who it was. Any other request's forwarding headers are ignored, since anyone can send them.
 * The client's address is the rightmost one in the chain that is not itself a trusted proxy, so a
 * client cannot pose as another by sending its own `X-Forwarded-For`. `trust` lists proxy
 * addresses and IPv4 ranges, or is `true` when every peer is a proxy (a container only a proxy
 * can reach).
 */
import type { App } from "../app.js";
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
export interface ProxyOptions {
    trust: true | string[];
}
export declare class TrustProxy extends Plugin {
    private readonly all;
    private readonly ranges;
    constructor(options: ProxyOptions);
    trusted(address: string): boolean;
    /** What the proxies forwarded for `c`, written onto it; nothing when its peer is not trusted. */
    apply(c: Context): void;
    setup(app: App): void;
}
