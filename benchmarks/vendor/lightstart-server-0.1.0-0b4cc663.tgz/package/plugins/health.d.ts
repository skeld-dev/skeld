/**
 * @file A health route for a load balancer or an orchestrator: GET (and HEAD) `/health` by default,
 * answering `{ "ok": true }`, or `{ "ok": false }` with a 503 when the check given says the server
 * cannot serve (its database is gone, it is draining). Never cached.
 */
import type { App } from "../app.js";
import { Plugin } from "../plugin.js";
export interface HealthOptions {
    path?: string;
    /** Whether the server can serve; healthy whenever it answers by default. */
    check?: () => Promise<boolean>;
}
export declare class Health extends Plugin {
    readonly options: HealthOptions;
    constructor(options?: HealthOptions);
    setup(app: App): void;
}
