import type { App } from "../app.js";
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
import { Reply } from "../reply.js";
/** A file's bytes after its transform: the body to send and its content type. */
export declare class Transformed {
    readonly body: Uint8Array;
    readonly type: string;
    constructor(body: Uint8Array, type: string);
}
export interface StaticOptions {
    /** The folder the files are in. */
    root: string;
    /** The URL prefix they are served under ("/assets"), the whole site by default. */
    prefix?: string;
    /** The file answering a folder, "index.html" by default. */
    index?: string;
    /** The file answering a path with no extension that nothing else answered, for a single-page app. */
    spa?: string;
    /** Serve files and folders whose name starts with a dot. */
    dotfiles?: boolean;
    /** The `cache-control` of every file, "no-cache" (revalidate every time) by default. */
    cacheControl?: string;
    /** Files larger than this many bytes are streamed instead of read whole; 256 KiB by default. */
    streamAbove?: number;
    /** The content type of a file, `mimeOf` by default: a host with a fuller table (the `mime` package) hands its own. */
    typeOf?: (path: string) => string;
    /** Answer with a file's `.br` or `.gz` neighbour when the client accepts it; true by default. A host that serves a build as it is turns it off. */
    precompressed?: boolean;
    /**
     * Turns a file's bytes into the body sent instead, or null to send the file as it is. The path
     * is the resolved file's; the body is read whole, so a transform that needs a large file sees it
     * in memory. A non-null answer is sent as bytes, never through a `.br`/`.gz` neighbour.
     */
    transform?: (path: string, body: Uint8Array) => Transformed | null;
    /** Which files the transform may change, asked before a file is read, so the others (images, media) are never read whole for it; every file when left out. */
    transformable?: (path: string) => boolean;
    /**
     * What the transform's output depends on beyond the file's own size and mtime (its code, an
     * importmap), as a string. It goes into every ETag as a hash while `transform` is set, so a
     * change in it revalidates files whose source did not move.
     */
    transformVersion?: string;
}
declare class Found {
    readonly path: string;
    readonly size: number;
    readonly mtime: number;
    constructor(path: string, size: number, mtime: number);
}
export declare class Static extends Plugin {
    readonly options: StaticOptions;
    private readonly root;
    constructor(options: StaticOptions);
    /** The file a request path (below the prefix) names, null when none does or the path is refused. */
    find(rest: string): Promise<Found | null>;
    /** The reply for the found file: a 304 when the client's copy is current, else the file or its compressed neighbour. */
    reply(c: Context, found: Found): Promise<Reply>;
    setup(app: App): void;
}
export {};
