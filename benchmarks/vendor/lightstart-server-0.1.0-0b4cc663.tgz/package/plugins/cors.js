/**
 * @file Cross-origin access: `app.plugin(new Cors({ origins: ["https://app.example"] }))`. A
 * preflight (an OPTIONS with `access-control-request-method`) under the prefix is answered before
 * routing with a 204 naming the methods, the headers asked for (or the configured ones) and how
 * long to keep the answer, granting the origin only when it is allowed; every other reply under
 * the prefix to an allowed origin carries the grant and `Vary: Origin`. An origin is allowed when
 * it is in `origins`, when `origins` is "*", or when `allow(origin, c)` says so (an allowlist read
 * from a Worker's `env` per request). With `credentials`, the grant names the origin and allows
 * credentials; "*" is never sent then, since browsers refuse it with credentials.
 */
                                     
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
import { Reply } from "../reply.js";

                              
                                             
                          
                                                                
                                                  
                                                                                
                  
                                                                                                                                                                        
                                    
                     
                                                                                        
                     
                                                
                    
                        
                                                                           
                  
 

const DEFAULT_METHODS = ["GET", "HEAD", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"];

export class Cors extends Plugin {
           options             ;

  constructor(options             ) {
    super("cors", []);
    this.options = options;
  }

  /** The `access-control-allow-origin` for `c`, "" when its origin is absent or not allowed. */
  grant(c         )         {
    const origin = c.header("origin");
    if (origin === null || origin === "") return "";
    const o = this.options;
    const listed = o.origins === "*" || o.origins.indexOf(origin) >= 0;
    if (!listed && (o.allow === undefined || !o.allow(origin, c))) return "";
    return o.origins === "*" && o.credentials !== true ? "*" : origin;
  }

          covers(c         )          {
    const prefix = this.options.prefix ?? "";
    if (prefix !== "" && !c.path.startsWith(prefix)) return false;
    const paths = this.options.paths;
    return paths === undefined || paths(c.path);
  }

          granted(reply       , origin        )       {
    reply.headers.set("access-control-allow-origin", origin);
    if (origin !== "*") reply.headers.append("vary", "Origin");
    if (this.options.credentials === true) reply.headers.set("access-control-allow-credentials", "true");
  }

  setup(app     )       {
    const o = this.options;
    const methods = (o.methods ?? DEFAULT_METHODS).join(", ");
    const allowed = o.headers === undefined ? "" : o.headers.join(", ");
    const maxAge = String(o.maxAge ?? 86400);
    const expose = o.expose === undefined ? "" : o.expose.join(", ");
    app.onRequest((c         )               => {
      if (c.method !== "OPTIONS" || c.header("access-control-request-method") === null || !this.covers(c)) return null;
      const reply = new Reply(204);
      const origin = this.grant(c);
      if (origin !== "") this.granted(reply, origin);
      reply.headers.set("access-control-allow-methods", methods);
      reply.headers.set("access-control-allow-headers", allowed !== "" ? allowed : (c.header("access-control-request-headers") ?? "content-type, authorization"));
      reply.headers.set("access-control-max-age", maxAge);
      reply.headers.append("vary", "Access-Control-Request-Headers");
      return reply;
    });
    app.onReply((c         , reply       )       => {
      if (reply.status === 204 && reply.headers.has("access-control-allow-methods")) return;
      if (!this.covers(c)) return;
      const origin = this.grant(c);
      if (origin === "") return;
      this.granted(reply, origin);
      if (expose !== "") reply.headers.set("access-control-expose-headers", expose);
    });
  }
}
