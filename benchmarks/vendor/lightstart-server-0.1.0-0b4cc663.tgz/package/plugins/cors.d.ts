/**
 * @file Cross-origin access: `app.plugin(new Cors({ origins: ["https://app.example"] }))`. A
 * preflight (an OPTIONS with `access-control-request-method`) under the prefix is answered before
 * routing with a 204 naming the methods, the headers asked for (or the configured ones) and how
 * long to keep the answer, granting the origin only when it is allowed; every other reply under
 * the prefix to an allowed origin carries the grant and `Vary: Origin`. An origin is allowed when
 * it is in `origins`, when `origins` is "*", or when `allow(origin, c)` says so (an allowlist read
 * from a Worker's `env` per request). With `credentials`, the grant names the origin and allows
 * credentials; "*" is never sent then, since browsers refuse it with credentials.
 */
import type { App } from "../app.js";
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
export interface CorsOptions {
    /** The origins allowed, or "*" for any. */
    origins: string[] | "*";
    /** Decides an origin `origins` does not list, per request. */
    allow?: (origin: string, c: Context) => boolean;
    /** Only paths under this prefix get CORS ("/api/"); every path by default. */
    prefix?: string;
    /** Narrows the covered paths further, per path (the routes a table declared CORS for); a preflight to another path is not answered here and routes as any request. */
    paths?: (path: string) => boolean;
    methods?: string[];
    /** The request headers a preflight allows; those the browser asked for by default. */
    headers?: string[];
    /** The response headers a script may read. */
    expose?: string[];
    credentials?: boolean;
    /** Seconds a browser may keep a preflight's answer, a day by default. */
    maxAge?: number;
}
export declare class Cors extends Plugin {
    readonly options: CorsOptions;
    constructor(options: CorsOptions);
    /** The `access-control-allow-origin` for `c`, "" when its origin is absent or not allowed. */
    grant(c: Context): string;
    private covers;
    private granted;
    setup(app: App): void;
}
