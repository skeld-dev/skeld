/**
 * @file The most bytes a request body may hold, for every request (`app.plugin(new BodyLimit(64 * 1024))`)
 * or for one route (`app.post("/upload", handler, [limit(50 * 1024 * 1024)])`). A body past it is
 * refused with a 413 as it is read, before it is kept whole.
 */
import type { App } from "../app.js";
import { Plugin } from "../plugin.js";
import type { Middleware } from "../router.js";
export declare class BodyLimit extends Plugin {
    readonly bytes: number;
    constructor(bytes: number);
    setup(app: App): void;
}
/** A route's own limit, over the app's. */
export declare const limit: (bytes: number) => Middleware;
