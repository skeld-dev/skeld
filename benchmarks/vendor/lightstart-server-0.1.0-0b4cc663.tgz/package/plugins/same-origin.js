/**
 * @file Refusing cross-origin unsafe requests before routing:
 * `app.plugin(new SameOrigin({ methods: ["POST"] }))`. A request whose method is in the set (POST,
 * PUT, PATCH and DELETE by default), or a websocket upgrade, is answered 403 unless
 * `Context.sameOrigin()` says it came from this origin or from no browser. A safe method and a
 * plain GET pass without a look at the headers.
 */
                                     
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
import { Reply, fail } from "../reply.js";

                                    
                                                                                       
                     
                                                                     
                     
 

const DEFAULT_METHODS = ["POST", "PUT", "PATCH", "DELETE"];

export class SameOrigin extends Plugin {
           options                   ;

  constructor(options                    = {}) {
    super("same-origin", []);
    this.options = options;
  }

  setup(app     )       {
    const methods           = [];
    for (const method of this.options.methods ?? DEFAULT_METHODS) methods.push(method.toUpperCase());
    const upgrades = this.options.upgrades !== false;
    app.onRequest((c         )               => {
      const upgrade = c.header("upgrade");
      const isUpgrade = upgrade !== null && upgrade !== "";
      if (!(upgrades && isUpgrade) && methods.indexOf(c.method) < 0) return null;
      if (c.sameOrigin()) return null;
      return fail("cross-origin request refused", 403);
    });
  }
}
