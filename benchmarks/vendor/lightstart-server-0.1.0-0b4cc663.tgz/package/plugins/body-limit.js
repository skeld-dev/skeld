/**
 * @file The most bytes a request body may hold, for every request (`app.plugin(new BodyLimit(64 * 1024))`)
 * or for one route (`app.post("/upload", handler, [limit(50 * 1024 * 1024)])`). A body past it is
 * refused with a 413 as it is read, before it is kept whole.
 */
                                     
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
import { Reply } from "../reply.js";
                                                     

export class BodyLimit extends Plugin {
           bytes        ;

  constructor(bytes        ) {
    super("body-limit", []);
    this.bytes = bytes;
  }

  setup(app     )       {
    const bytes = this.bytes;
    app.onRequest((c         )               => {
      c.limit = bytes;
      return null;
    });
  }
}

/** A route's own limit, over the app's. */
export const limit = (bytes        )             => (c         , next      )                 => {
  c.limit = bytes;
  return next();
};
