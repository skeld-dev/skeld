/** The extension of the last segment of `path`, lower-cased with its dot, "" when it has none. */
export declare const extensionOf: (path: string) => string;
/** The content type of a file named `path`. */
export declare const mimeOf: (path: string) => string;
