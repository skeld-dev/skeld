/**
 * @file One line per request, written when its reply is ready: the method, the path, the status, the
 * milliseconds it took and the client's address (`GET /carts/7 200 1.4ms 203.0.113.9`). The lines
 * go to stdout by default; a `LineSink` subclass sends them elsewhere, a test keeps them.
 */
import type { App } from "../app.js";
import { Plugin } from "../plugin.js";
export declare class LineSink {
    write(line: string): void;
}
export declare class AccessLog extends Plugin {
    readonly sink: LineSink;
    /** The clock it measures with, milliseconds; a test fixes it. */
    readonly clock: () => number;
    constructor(sink?: LineSink, clock?: () => number);
    setup(app: App): void;
}
