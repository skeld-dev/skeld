/**
 * @file A request id on every request and its reply: the incoming `x-request-id` when it is a
 * plausible id (at most 128 characters of letters, digits and `-_.:`), so a trace crosses the
 * proxy in front, else a new random UUID. A handler reads it with `c.get(REQUEST_ID)`; every reply
 * carries it back in the same header.
 */
import type { App } from "../app.js";
import { Key } from "../key.js";
import { Plugin } from "../plugin.js";
export declare const REQUEST_ID: Key<string>;
export declare class RequestId extends Plugin {
    readonly header: string;
    constructor(header?: string);
    setup(app: App): void;
}
