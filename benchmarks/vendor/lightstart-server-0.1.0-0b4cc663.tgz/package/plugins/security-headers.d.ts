/**
 * @file Security headers on every reply: `app.plugin(new SecurityHeaders())`. The defaults are
 * `X-Content-Type-Options: nosniff`, `X-Frame-Options: SAMEORIGIN`, `Referrer-Policy:
 * strict-origin-when-cross-origin` and `Cross-Origin-Opener-Policy: same-origin`, plus
 * `Strict-Transport-Security` on replies to https requests; `Content-Security-Policy` and
 * `Permissions-Policy` are off unless given (a default CSP breaks apps silently). Every header is
 * overridable, and `false` turns one off. The name/value lists are built once in `setup`, and the
 * reply hook writes them with `default`, so a header a reply set itself keeps its value. A route
 * opts out by listing `noSecurityHeaders` among its middleware.
 */
import type { App } from "../app.js";
import type { Context } from "../context.js";
import { Plugin } from "../plugin.js";
import type { Reply } from "../reply.js";
import type { Next } from "../router.js";
export interface SecurityHeadersOptions {
    /** `X-Content-Type-Options`; `nosniff` unless changed, false to omit it. */
    contentTypeOptions?: string | false;
    /** `X-Frame-Options`; SAMEORIGIN unless changed, false to omit it. */
    frameOptions?: "DENY" | "SAMEORIGIN" | false;
    /** `Referrer-Policy`; `strict-origin-when-cross-origin` unless changed, false to omit it. */
    referrerPolicy?: string | false;
    /** `Cross-Origin-Opener-Policy`; `same-origin` unless changed, false to omit it. */
    openerPolicy?: string | false;
    /** `Strict-Transport-Security` on https replies; the default one year with subdomains, false to omit it. */
    hsts?: string | false;
    /** `Content-Security-Policy`; off unless given, false to leave it off. */
    csp?: string | false;
    /** `Permissions-Policy`; off unless given, false to leave it off. */
    permissionsPolicy?: string | false;
}
export declare class SecurityHeaders extends Plugin {
    readonly options: SecurityHeadersOptions;
    constructor(options?: SecurityHeadersOptions);
    setup(app: App): void;
}
/**
 * A route's middleware opting it out of `SecurityHeaders`: `app.get("/embed", handler,
 * [noSecurityHeaders])`. It marks the request, which the reply hook reads once per reply.
 */
export declare const noSecurityHeaders: (c: Context, next: Next) => Promise<Reply>;
