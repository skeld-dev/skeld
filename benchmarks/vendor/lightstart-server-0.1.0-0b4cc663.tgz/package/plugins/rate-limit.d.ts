/**
 * @file Refusing a caller that asks too often: `app.get("/", handler, [rateLimit({ window: 60_000, max: 30 })])`
 * for one route, or `app.plugin(new RateLimit({ window: 60_000, max: 30 }))` for every route. A fixed
 * window per key (the client's address unless `key` says otherwise) counts the requests of the
 * window; the limit's reply carries `RateLimit-Limit`, `RateLimit-Remaining` and `RateLimit-Reset`,
 * and a request past the limit is answered 429 with `Retry-After` without reaching the handler. The
 * state sits behind `RateStore`, which may answer at once or asynchronously, so a SQLite or D1 store
 * can replace the in-memory one. The app-wide form contributes middleware rather than a request
 * hook, since a store may answer a promise and the hooks are synchronous.
 */
import type { App } from "../app.js";
import { Context } from "../context.js";
import { Plugin } from "../plugin.js";
import type { Middleware } from "../router.js";
/** One key's count in its window: how many requests it has made, and when the count restarts (epoch ms). */
export declare class RateHit {
    count: number;
    reset: number;
    constructor(count: number, reset: number);
}
/** Where a limit's counts live; a promise lets a database-backed store answer without blocking. */
export interface RateStore {
    hit(key: string, windowMs: number, now: number): RateHit | Promise<RateHit>;
}
/**
 * A fixed window per key in memory, bounded: expired entries are swept every 256 hits and when
 * asked, and past `maxKeys` the oldest key is evicted, so many distinct addresses cannot grow it
 * without limit. Suitable for one process; a host with several processes shares a real store.
 */
export declare class MemoryRateStore implements RateStore {
    private readonly entries;
    private readonly maxKeys;
    private hits;
    constructor(maxKeys?: number);
    /** How many keys the store holds now, after any sweep. */
    get size(): number;
    /** Drops every key whose window ended at or before `now`. */
    sweep(now: number): void;
    private evictOldest;
    hit(key: string, windowMs: number, now: number): RateHit;
}
/** A route's limit: the window in milliseconds, the most requests allowed in it, and how a caller is named. */
export interface RateLimitOptions {
    /** The length of a window, in milliseconds. */
    window: number;
    /** The most requests one key may make in a window; the next is a 429. */
    max: number;
    /** Names the caller; the client's address (`c.ip`) by default. */
    key?: (c: Context) => string;
    /** Where counts live; a new `MemoryRateStore()` by default. */
    store?: RateStore;
    /** Requests it answers true for are not counted and not limited. */
    skip?: (c: Context) => boolean;
    /** The 429's message, "too many requests" by default. */
    message?: string;
    /** The clock, `Date.now` by default; a test passes a fixed one. */
    now?: () => number;
}
/** A limit as middleware for a route's own list, inside the app's middleware. */
export declare const rateLimit: (options: RateLimitOptions) => Middleware;
/** The same limit on every request of the app, added with `app.plugin(new RateLimit(options))`. */
export declare class RateLimit extends Plugin {
    readonly options: RateLimitOptions;
    constructor(options: RateLimitOptions);
    setup(app: App): void;
}
