/**
 * @file Refusing cross-origin unsafe requests before routing:
 * `app.plugin(new SameOrigin({ methods: ["POST"] }))`. A request whose method is in the set (POST,
 * PUT, PATCH and DELETE by default), or a websocket upgrade, is answered 403 unless
 * `Context.sameOrigin()` says it came from this origin or from no browser. A safe method and a
 * plain GET pass without a look at the headers.
 */
import type { App } from "../app.js";
import { Plugin } from "../plugin.js";
export interface SameOriginOptions {
    /** The methods refused when cross-origin; POST, PUT, PATCH and DELETE by default. */
    methods?: string[];
    /** Whether websocket upgrades are checked too; true by default. */
    upgrades?: boolean;
}
export declare class SameOrigin extends Plugin {
    readonly options: SameOriginOptions;
    constructor(options?: SameOriginOptions);
    setup(app: App): void;
}
