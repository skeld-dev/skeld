/**
 * @file One line per request, written when its reply is ready: the method, the path, the status, the
 * milliseconds it took and the client's address (`GET /carts/7 200 1.4ms 203.0.113.9`). The lines
 * go to stdout by default; a `LineSink` subclass sends them elsewhere, a test keeps them.
 */
                                     
import { Context } from "../context.js";
import { Key } from "../key.js";
import { Plugin } from "../plugin.js";
import { Reply } from "../reply.js";

export class LineSink {
  write(line        )       {
    console.log(line);
  }
}

const STARTED = new Key        ("access log start");

export class AccessLog extends Plugin {
           sink          ;
  /** The clock it measures with, milliseconds; a test fixes it. */
           clock              ;

  constructor(sink           = new LineSink(), clock               = () => performance.now()) {
    super("access-log", []);
    this.sink = sink;
    this.clock = clock;
  }

  setup(app     )       {
    const clock = this.clock;
    const sink = this.sink;
    app.onRequest((c         )               => {
      c.set(STARTED, clock());
      return null;
    });
    app.onReply((c         , reply       )       => {
      const started = c.get(STARTED) ?? clock();
      const status = reply.response !== null ? reply.response.status : reply.status;
      sink.write(c.method + " " + c.path + " " + String(status) + " " + (clock() - started).toFixed(1) + "ms " + c.ip);
    });
  }
}
