export declare class Key<T> {
    readonly id: number;
    readonly name: string;
    readonly type: T;
    constructor(name: string);
}
/**
 * Values by key, in two parallel lists scanned in order: a request holds a handful, where a
 * `Map` keyed by objects costs more natively than the scan.
 */
export declare class Slots {
    readonly ids: number[];
    readonly values: unknown[];
    read(id: number): unknown;
    write(id: number, value: unknown): void;
}
